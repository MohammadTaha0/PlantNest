<?php

namespace App\Http\Controllers;

use App\Models\Category;
use Illuminate\Http\Client\ResponseSequence;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Validator;

class CategoryController extends Controller
{
    public function create()
    {
        return view('backend.Category.create');
    }
    public function created(Request $request)
    {
        $validator = Validator::make($request->all(), [
            'name' => 'required|unique:categories,name',
        ]);
        if ($validator->fails()) {
            return response()->json(['status' => 403, 'msg' => $validator->errors()->all()]);
        }
        $cat = new Category();
        $cat->name = $request->name;
        $cat->save();
        return response()->json(['status' => 200, 'msg' => 'Category Created Successfully <i
        class="fa-regular fa-check"></i>']);
    }
    public function admin_index()
    {
        return view('backend.Category.index');
    }
    public function categories()
    {
        return response()->json(['status' => 200, 'data' => Category::orderBy('id','desc')->paginate(20)]);
    }
    public function edited(Request $request)
    {
        if ($request->id == null) {
            return;
        }
        $validator = Validator::make($request->all(), [
            'name' => 'required|unique:categories,name,' . $request->id,
        ]);
        if ($validator->fails()) {
            return response()->json(['status' => 403, 'msg' => $validator->errors()->all()]);
        }
        $cat = Category::find($request->id);
        if ($cat) {
            $cat->name = $request->name;
            if ($request->status != null) {
                $cat->status = $request->status;
            }
            $cat->save();
            return response()->json(['status' => 200, 'msg' => 'Category Updated Successfully <i
            class="fa-regular fa-check"></i>', 'data' => $cat]);
        }

        return response()->json(['status' => 404, 'msg' => 'Not Found']);
    }
    public function deleted(Request $request)
    {
        if ($request->id == null) {
            return;
        }
        $cat = Category::find($request->id);
        if ($cat) {
            $cat->delete();
            return response()->json(['status' => 200, 'msg' => 'Category Deleted Successfully <i
            class="fa-regular fa-check"></i>', 'data' => $request->id]);
        }

        return response()->json(['status' => 404, 'msg' => 'Not Found']);
    }
}

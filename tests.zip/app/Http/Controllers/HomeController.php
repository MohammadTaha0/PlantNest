<?php

namespace App\Http\Controllers;

use App\Models\Plant;
use Illuminate\Http\Request;

class HomeController extends Controller
{
    public function index()
    {
        $plants = Plant::where('status','1')->select('plants.id', 'plants.name', 'feature', 'price', 'stock', 'views', 'searches','images');
        $latest = clone $plants;
        $latest = $latest->orderBy('id', 'desc')->limit(8)->get();
        $famouse = clone $plants;
        $famouse = $famouse->orderBy('views', 'desc')->limit(8)->get();
        $mostSearches = clone $plants;
        $mostSearches = $mostSearches->orderBy('searches', 'desc')->limit(8)->get();
        return view('frontend.index')->with(compact('latest','famouse','mostSearches'));
    }
}

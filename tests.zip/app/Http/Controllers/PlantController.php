<?php

namespace App\Http\Controllers;

use App\Models\Category;
use App\Models\Plant;
use Illuminate\Http\Client\ResponseSequence;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\File;
use Illuminate\Support\Facades\Validator;

class PlantController extends Controller
{
    public function cart()
    {
        return view('frontend.cart');
    }
    public function add_cart(Request $request)
    {
        $cart = session()->get('cart');
        if (!$cart) {
            $cart = [];
        }
        $id = $request->id;
        $data = null;
        $cartIds = array_column($cart, 'id');
        if (!in_array($id, $cartIds)) {
            $cart[] = ['id' => $id, 'qty' => 1];
            $data = Plant::select('id', 'name', 'feature', 'price', 'stock', 'quantity')->find($id);
            session()->put('cart', $cart);
            $msg = 'Add In ';
        } else {
            $cart = array_filter($cart, function ($item) use ($id) {
                return !($item['id'] === $id);
            });
            session()->put('cart', $cart);
            $msg = 'Removed From ';
        }
        return response()->json(['status' => 200, 'qty' => count(session('cart')), 'msg' => $msg . 'Cart.', 'data' => $data]);
    }
    public function get_cart(Request $request)
    {
        if (!session('cart')) {
            return response()->json(['status' => 404, 'msg' => 'Empty Cart!']);
        }
        $cart = session('cart');
        if ($request->short == '1') {
            $cartIds = array_column($cart, 'id');
            $carts = Plant::whereIn('id', $cartIds)
                ->where('status', '1')
                ->select('id', 'name', 'feature', 'quantity', 'price', 'stock')
                ->get();

            $carts->each(function ($cartItem) use ($cart) {
                $matchingCartItem = collect($cart)->firstWhere('id', $cartItem->id);
                $cartItem->qty = $matchingCartItem['qty'] ?? 0;
            });
            return response()->json(['status' => 200, 'data' => $carts]);
        }
    }
    public function update_qty(Request $request)
    {
        $cart = session('cart');
        if (!$cart || !in_array($request->id, array_column($cart, 'id'))) {
            return response()->json(['status' => 404, 'msg1' => '404 not found']);
        }
        $id = $request->id;
        $qty = $request->qty;
        $plant = Plant::find($request->id);
        if($plant && $plant->quantity < $qty){
            return response()->json(['status'=>203,'msg'=>'Quantity exceeds available stock.']);
        }
        $cart = array_map(function ($item) use ($id, $qty) {
            if ($item['id'] === $id) {
                $item['qty'] = $qty;
            }
            return $item;
        }, $cart);
        session()->put('cart', $cart);
        return response()->json(['status'=>200]);
    }
    public function shop_get(Request $request)
    {
        $sorting = [
            'd' => ['id', 'desc'],
            'f' => ['views', 'desc'],
            'l' => ['id', 'desc'],
            'hp' => ['price', 'desc'],
            'lp' => ['price', 'asc'],
        ];
        $sort = $sorting[$request->sort];

        $cats = Category::join('plants as p', 'p.category', '=', 'categories.id')
            ->where([['p.status', '1'], ['categories.status', '1']])
            ->select('categories.id', 'categories.name', DB::raw('COUNT(p.id) as totals'))
            ->groupBy('categories.id', 'categories.name')
            ->get();
        $data = Plant::where('plants.status', '1')->orderBy('plants.' . $sort[0], $sort[1]);
        $min = clone $data;
        $max = clone $data;
        $min = $min->min('price');
        $max = $max->max('price');
        if ($request->price_from && $request->price_to) {
            $data = $data->whereBetween('price', [$request->price_from, $request->price_to]);
        }
        if ($request->category) {
            $data = $data->where('category', $request->category);
        }
        if ($request->key) {
            $data = $data->where('plants.name', 'LIKE', '%' . "$request->key" . '%');
        }
        $carts = [['id'=>'0','qty'=>'1']];
        if (session('cart')) {
            $carts = session('cart');
        }
        $carts = implode(',', array_column($carts, 'id'));
        $plants = $data->select('plants.id', 'plants.name', 'feature', 'price', 'stock', 'views', 'searches', 'images')
            ->addSelect(DB::raw('IF(plants.id IN (' .  $carts . '), 1, 0) as in_cart'))
            ->paginate(9);
        return response()->json(['status' => 200, 'data' => $plants, 'categories' => $cats, 'min' => $min, 'max' => $max]);
    }
    public function shop()
    {
        return view('frontend.shop');
    }
    public function create()
    {
        $countries = array("Afghanistan", "Albania", "Algeria", "American Samoa", "Andorra", "Angola", "Anguilla", "Antarctica", "Antigua and Barbuda", "Argentina", "Armenia", "Aruba", "Australia", "Austria", "Azerbaijan", "Bahamas", "Bahrain", "Bangladesh", "Barbados", "Belarus", "Belgium", "Belize", "Benin", "Bermuda", "Bhutan", "Bolivia", "Bosnia and Herzegowina", "Botswana", "Bouvet Island", "Brazil", "British Indian Ocean Territory", "Brunei Darussalam", "Bulgaria", "Burkina Faso", "Burundi", "Cambodia", "Cameroon", "Canada", "Cape Verde", "Cayman Islands", "Central African Republic", "Chad", "Chile", "China", "Christmas Island", "Cocos (Keeling) Islands", "Colombia", "Comoros", "Congo", "Congo, the Democratic Republic of the", "Cook Islands", "Costa Rica", "Cote d'Ivoire", "Croatia (Hrvatska)", "Cuba", "Cyprus", "Czech Republic", "Denmark", "Djibouti", "Dominica", "Dominican Republic", "East Timor", "Ecuador", "Egypt", "El Salvador", "Equatorial Guinea", "Eritrea", "Estonia", "Ethiopia", "Falkland Islands (Malvinas)", "Faroe Islands", "Fiji", "Finland", "France", "France Metropolitan", "French Guiana", "French Polynesia", "French Southern Territories", "Gabon", "Gambia", "Georgia", "Germany", "Ghana", "Gibraltar", "Greece", "Greenland", "Grenada", "Guadeloupe", "Guam", "Guatemala", "Guinea", "Guinea-Bissau", "Guyana", "Haiti", "Heard and Mc Donald Islands", "Holy See (Vatican City State)", "Honduras", "Hong Kong", "Hungary", "Iceland", "India", "Indonesia", "Iran (Islamic Republic of)", "Iraq", "Ireland", "Israel", "Italy", "Jamaica", "Japan", "Jordan", "Kazakhstan", "Kenya", "Kiribati", "Korea, Democratic People's Republic of", "Korea, Republic of", "Kuwait", "Kyrgyzstan", "Lao, People's Democratic Republic", "Latvia", "Lebanon", "Lesotho", "Liberia", "Libyan Arab Jamahiriya", "Liechtenstein", "Lithuania", "Luxembourg", "Macau", "Macedonia, The Former Yugoslav Republic of", "Madagascar", "Malawi", "Malaysia", "Maldives", "Mali", "Malta", "Marshall Islands", "Martinique", "Mauritania", "Mauritius", "Mayotte", "Mexico", "Micronesia, Federated States of", "Moldova, Republic of", "Monaco", "Mongolia", "Montserrat", "Morocco", "Mozambique", "Myanmar", "Namibia", "Nauru", "Nepal", "Netherlands", "Netherlands Antilles", "New Caledonia", "New Zealand", "Nicaragua", "Niger", "Nigeria", "Niue", "Norfolk Island", "Northern Mariana Islands", "Norway", "Oman", "Pakistan", "Palau", "Panama", "Papua New Guinea", "Paraguay", "Peru", "Philippines", "Pitcairn", "Poland", "Portugal", "Puerto Rico", "Qatar", "Reunion", "Romania", "Russian Federation", "Rwanda", "Saint Kitts and Nevis", "Saint Lucia", "Saint Vincent and the Grenadines", "Samoa", "San Marino", "Sao Tome and Principe", "Saudi Arabia", "Senegal", "Seychelles", "Sierra Leone", "Singapore", "Slovakia (Slovak Republic)", "Slovenia", "Solomon Islands", "Somalia", "South Africa", "South Georgia and the South Sandwich Islands", "Spain", "Sri Lanka", "St. Helena", "St. Pierre and Miquelon", "Sudan", "Suriname", "Svalbard and Jan Mayen Islands", "Swaziland", "Sweden", "Switzerland", "Syrian Arab Republic", "Taiwan, Province of China", "Tajikistan", "Tanzania, United Republic of", "Thailand", "Togo", "Tokelau", "Tonga", "Trinidad and Tobago", "Tunisia", "Turkey", "Turkmenistan", "Turks and Caicos Islands", "Tuvalu", "Uganda", "Ukraine", "United Arab Emirates", "United Kingdom", "United States", "United States Minor Outlying Islands", "Uruguay", "Uzbekistan", "Vanuatu", "Venezuela", "Vietnam", "Virgin Islands (British)", "Virgin Islands (U.S.)", "Wallis and Futuna Islands", "Western Sahara", "Yemen", "Yugoslavia", "Zambia", "Zimbabwe");

        $cats = Category::where('status', '1')->get(['id', 'name']);
        return view('backend.Plant.create')->with(compact('cats', 'countries'));
    }
    public function created(Request $request)
    {
        $validator = Validator::make($request->all(), [
            'name' => 'required|min:4|max:70|unique:plants,name',
            'feature_image' => 'required|image|mimes:png,jpg,jpeg',
            'image' => 'required',
            'category' => 'required|exists:categories,id',
            'description' => 'required|max:800|min:20',
            'price' => 'required',
            'scientific_name' => 'required',
            'country' => 'required',
            'water_cycle' => 'required',
            'water_cycle_quantity' => 'required',
            'water_cycle_time' => 'required',
        ], [
            'water_cycle.required' => 'Water Cycle Amount Required!',
            'water_cycle_quantity.required' => 'Water Quatity Required!',
            'water_cycle_time.required' => 'Water Quatity Per Time Required!',
        ]);
        if ($validator->fails()) {
            return response()->json(['status' => 403, 'msg' => $validator->errors()->all()]);
        }
        $file = $request->file('feature_image');
        $fileName = uniqid() . '.' . $file->getClientOriginalExtension();
        $fileNames = [];
        foreach ($request->file('image') as $image) {
            $name = uniqid() . '.' . $image->getClientOriginalExtension();
            $fileNames[] = $name;
            $image->storeAs('public/images', $name);
        };
        $plant = new Plant();
        $plant->name = $request->name;
        $plant->feature = $fileName;
        $plant->images = implode(',', $fileNames);
        $plant->category = $request->category;
        $plant->description = $request->description;
        $plant->price = $request->price;
        if ($request->discount) {
            $plant->discount = $request->discount;
        }
        $plant->scientific_name = $request->scientific_name;
        $plant->country = $request->country;
        $plant->water_cycle = $request->water_cycle;
        $plant->water_quantity = $request->water_cycle_quantity;
        $plant->water_cycle_time = $request->water_cycle_time;
        if ($request->light && $request->light_quantity && $request->light_time) {
            $plant->light = $request->light;
            $plant->light_quantity = $request->light_quantity;
            $plant->light_time = $request->light_time;
        }
        $plant->quantity = $request->quantity;
        if ($plant->quantity <= 0) {
            $plant->stock = '0';
        }
        $file->storeAs('public/images', $fileName);
        $plant->save();
        return response()->json(['status' => 200, 'msg' => 'Plant Created Successfully <i
        class="fa-regular fa-check"></i>']);
    }
    public function admin_index()
    {
        return view('backend.Plant.index');
    }
    public function plants()
    {
        return response()->json(['status' => 200, 'data' => Plant::join('categories as c', 'c.id', '=', 'plants.category')->select('plants.id', 'plants.name', 'feature', 'images', 'c.name as category', 'price', 'quantity', 'stock', 'views', 'searches', 'plants.status', 'plants.created_at', 'plants.updated_at')->orderBy('plants.id', 'desc')->paginate(20)]);
    }
    public function edit($id)
    {
        $countries = array("Afghanistan", "Albania", "Algeria", "American Samoa", "Andorra", "Angola", "Anguilla", "Antarctica", "Antigua and Barbuda", "Argentina", "Armenia", "Aruba", "Australia", "Austria", "Azerbaijan", "Bahamas", "Bahrain", "Bangladesh", "Barbados", "Belarus", "Belgium", "Belize", "Benin", "Bermuda", "Bhutan", "Bolivia", "Bosnia and Herzegowina", "Botswana", "Bouvet Island", "Brazil", "British Indian Ocean Territory", "Brunei Darussalam", "Bulgaria", "Burkina Faso", "Burundi", "Cambodia", "Cameroon", "Canada", "Cape Verde", "Cayman Islands", "Central African Republic", "Chad", "Chile", "China", "Christmas Island", "Cocos (Keeling) Islands", "Colombia", "Comoros", "Congo", "Congo, the Democratic Republic of the", "Cook Islands", "Costa Rica", "Cote d'Ivoire", "Croatia (Hrvatska)", "Cuba", "Cyprus", "Czech Republic", "Denmark", "Djibouti", "Dominica", "Dominican Republic", "East Timor", "Ecuador", "Egypt", "El Salvador", "Equatorial Guinea", "Eritrea", "Estonia", "Ethiopia", "Falkland Islands (Malvinas)", "Faroe Islands", "Fiji", "Finland", "France", "France Metropolitan", "French Guiana", "French Polynesia", "French Southern Territories", "Gabon", "Gambia", "Georgia", "Germany", "Ghana", "Gibraltar", "Greece", "Greenland", "Grenada", "Guadeloupe", "Guam", "Guatemala", "Guinea", "Guinea-Bissau", "Guyana", "Haiti", "Heard and Mc Donald Islands", "Holy See (Vatican City State)", "Honduras", "Hong Kong", "Hungary", "Iceland", "India", "Indonesia", "Iran (Islamic Republic of)", "Iraq", "Ireland", "Israel", "Italy", "Jamaica", "Japan", "Jordan", "Kazakhstan", "Kenya", "Kiribati", "Korea, Democratic People's Republic of", "Korea, Republic of", "Kuwait", "Kyrgyzstan", "Lao, People's Democratic Republic", "Latvia", "Lebanon", "Lesotho", "Liberia", "Libyan Arab Jamahiriya", "Liechtenstein", "Lithuania", "Luxembourg", "Macau", "Macedonia, The Former Yugoslav Republic of", "Madagascar", "Malawi", "Malaysia", "Maldives", "Mali", "Malta", "Marshall Islands", "Martinique", "Mauritania", "Mauritius", "Mayotte", "Mexico", "Micronesia, Federated States of", "Moldova, Republic of", "Monaco", "Mongolia", "Montserrat", "Morocco", "Mozambique", "Myanmar", "Namibia", "Nauru", "Nepal", "Netherlands", "Netherlands Antilles", "New Caledonia", "New Zealand", "Nicaragua", "Niger", "Nigeria", "Niue", "Norfolk Island", "Northern Mariana Islands", "Norway", "Oman", "Pakistan", "Palau", "Panama", "Papua New Guinea", "Paraguay", "Peru", "Philippines", "Pitcairn", "Poland", "Portugal", "Puerto Rico", "Qatar", "Reunion", "Romania", "Russian Federation", "Rwanda", "Saint Kitts and Nevis", "Saint Lucia", "Saint Vincent and the Grenadines", "Samoa", "San Marino", "Sao Tome and Principe", "Saudi Arabia", "Senegal", "Seychelles", "Sierra Leone", "Singapore", "Slovakia (Slovak Republic)", "Slovenia", "Solomon Islands", "Somalia", "South Africa", "South Georgia and the South Sandwich Islands", "Spain", "Sri Lanka", "St. Helena", "St. Pierre and Miquelon", "Sudan", "Suriname", "Svalbard and Jan Mayen Islands", "Swaziland", "Sweden", "Switzerland", "Syrian Arab Republic", "Taiwan, Province of China", "Tajikistan", "Tanzania, United Republic of", "Thailand", "Togo", "Tokelau", "Tonga", "Trinidad and Tobago", "Tunisia", "Turkey", "Turkmenistan", "Turks and Caicos Islands", "Tuvalu", "Uganda", "Ukraine", "United Arab Emirates", "United Kingdom", "United States", "United States Minor Outlying Islands", "Uruguay", "Uzbekistan", "Vanuatu", "Venezuela", "Vietnam", "Virgin Islands (British)", "Virgin Islands (U.S.)", "Wallis and Futuna Islands", "Western Sahara", "Yemen", "Yugoslavia", "Zambia", "Zimbabwe");

        $cats = Category::where('status', '1')->get(['id', 'name']);
        $plant = Plant::find($id);
        if (!$plant) {
            return abort('404', 'Data Not Found!');
        }
        return view('backend.Plant.edit')->with(compact('cats', 'countries', 'plant'));
    }
    public function edited(Request $request)
    {
        if ($request->id == null) {
            return abort(404, 'Data not found');
        }
        $validator = Validator::make($request->all(), [
            'name' => 'required|min:4|max:70|unique:plants,name,' . $request->id,
            'category' => 'required|exists:categories,id',
            'description' => 'required|max:800|min:20',
            'price' => 'required',
            'scientific_name' => 'required',
            'country' => 'required',
            'water_cycle' => 'required',
            'water_cycle_quantity' => 'required',
            'water_cycle_time' => 'required',
            // 'light' => 'required',
            // 'light_quantity' => 'required',
            // 'light_time' => 'required',
            // 'price' => 'required',
        ], [
            'water_cycle.required' => 'Water Cycle Amount Required!',
            'water_cycle_quantity.required' => 'Water Quatity Required!',
            'water_cycle_time.required' => 'Water Quatity Per Time Required!',

            //    'light.required'=>'light Amount Required!', 
            //    'light_quantity.required'=>'Light Quatity Required!', 
            //    'light_time.required'=>'Light Quatity Per Time Required!', 
        ]);
        if ($validator->fails()) {
            return response()->json(['status' => 403, 'msg' => $validator->errors()->all()]);
        }
        $plant = Plant::find($request->id);
        if (!$plant) {
            return abort(404, 'Data not found');
        }
        $fileName = $plant->feature;
        if ($request->file('feature_image') != null) {
            $path = public_path('storage/images/' . $fileName);
            if (File::exists($path)) {
                File::delete($path);
            }
            $file = $request->file('feature_image');
            $fileName = uniqid() . '.' . $file->getClientOriginalExtension();
            $file->storeAs('public/images', $fileName);
        }
        $image_1 = '';
        $image_2 = '';
        $image_3 = '';
        $fileNames = explode(',', $plant->images);
        if ($request->file('image_1') != null) {
            $path = public_path('storage/images/' . $fileNames[0]);
            if (File::exists($path)) {
                File::delete($path);
            }
            $file = $request->file('image_1');
            $image_1 = uniqid() . '.' . $file->getClientOriginalExtension();
            $fileNames[0] = $image_1;
            $file->storeAs('public/images', $image_1);
        }
        if ($request->file('image_2') != null) {
            $path = public_path('storage/images/' . $fileNames[1]);
            if (File::exists($path)) {
                File::delete($path);
            }
            $file = $request->file('image_2');
            $image_2 = uniqid() . '.' . $file->getClientOriginalExtension();
            $fileNames[1] = $image_2;
            $file->storeAs('public/images', $image_2);
        }
        if ($request->file('image_3') != null) {
            $path = public_path('storage/images/' . $fileNames[2]);
            if (File::exists($path)) {
                File::delete($path);
            }
            $file = $request->file('image_3');
            $image_3 = uniqid() . '.' . $file->getClientOriginalExtension();
            $fileNames[2] = $image_3;
            $file->storeAs('public/images', $image_3);
        }
        $plant->name = $request->name;
        $plant->feature = $fileName;
        $plant->images = implode(',', $fileNames);
        $plant->category = $request->category;
        $plant->description = $request->description;
        $plant->price = $request->price;
        if ($request->discount) {
            $plant->discount = $request->discount;
        }
        $plant->scientific_name = $request->scientific_name;
        $plant->country = $request->country;
        $plant->water_cycle = $request->water_cycle;
        $plant->water_quantity = $request->water_cycle_quantity;
        $plant->water_cycle_time = $request->water_cycle_time;
        if ($request->light && $request->light_quantity && $request->light_time) {
            $plant->light = $request->light;
            $plant->light_quantity = $request->light_quantity;
            $plant->light_time = $request->light_time;
        }
        $plant->quantity = $request->quantity;
        if ($plant->quantity <= 0) {
            $plant->stock = '0';
        }
        $plant->save();
        return response()->json(['status' => 200, 'msg' => 'Plant Updated Successfully <i
        class="fa-regular fa-check"></i>']);

        return response()->json(['status' => 404, 'msg' => 'Not Found']);
    }
    public function deleted(Request $request)
    {
        if ($request->id == null) {
            return;
        }
        $cat = Plant::find($request->id);
        if ($cat) {
            $cat->delete();
            return response()->json(['status' => 200, 'msg' => 'Plant Deleted Successfully <i
            class="fa-regular fa-check"></i>', 'data' => $request->id]);
        }

        return response()->json(['status' => 404, 'msg' => 'Not Found']);
    }
}

<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('plants', function (Blueprint $table) {
            $table->id();
            $table->string('name');
            $table->string('feature');
            $table->longText('images');
            $table->bigInteger('category');
            $table->longText('description');
            $table->decimal('price');
            $table->decimal('discount');
            $table->bigInteger('views');
            $table->bigInteger('searches');
            $table->string('scientific_name');
            $table->string('country');
            $table->decimal('water_cycle');
            $table->string('water_quantity');
            $table->string('water_cycle_time');
            $table->bigInteger('light');
            $table->string('light_quantity');
            $table->string('light_time');
            $table->bigInteger('quantity');
            $table->enum('status',['0','1'])->default('1');
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('plants');
    }
};

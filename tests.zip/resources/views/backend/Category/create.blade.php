@extends('backend.layout.main')
@section('main')
    <div class="page-content">
        <div class="container-fluid">
            <form id="form-create"
                class="row row-cols-1 px-0 col-6 justify-content-center shadow mx-auto gy-3 pb-2 border rounded-2 overflow-hidden">
                <div class="col p-0">
                    <h3 class="h5 text-center bg-dark text-light py-3">Create Category</h3>
                </div>
                @csrf
                <div class="col">
                    <input type="text" class="form-control" name="name" placeholder="Enter Name">
                </div>
                <div class="col">
                    <button type="submit" class="btn btn-outline-primary">Create <i
                            class="fa-regular fa-check"></i></button>
                </div>
            </form>
        </div>
    </div>
    <script>
        $(document).ready(function() {
            function msg(text, type) {
                $("#alert-box").prepend(`
                    <div class="alert alert-${type} alert-dismissible" role="alert">
                        ${text}
                        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                    </div>
                `);
            };
            $("#form-create").on('submit', function(e) {
                e.preventDefault();
                let formData = new FormData(this);
                let btn = $(this).find('button[type="submit"]');
                let btnHtml = btn.html();
                btn.html(`<span class='spinner-border spinner-border-sm'></span>`);
                btn.attr('disabled', 'disabled');
                $.ajax({
                    url: '{{ route('admin.category.created') }}',
                    type: 'post',
                    data: formData,
                    contentType: false,
                    processData: false,
                    success: function(res) {
                        btn.html(btnHtml);
                        btn.removeAttr('disabled');
                        if (res.status === 200) {
                            msg(res.msg, 'success');
                            $(".form-control").val('');
                            $(".form-select").val('');
                        } else if (res.status === 403) {
                            for (const msgs of res.msg) {
                                msg(msgs, 'danger');
                            }
                        } else {
                            msg('Something Went Wromg! Try Again Later!', 'danger');
                        }
                    },
                    error: function(err) {
                        btn.html(btnHtml);
                        btn.removeAttr('disabled');
                        msg('Something Went Wromg! Try Again Later!', 'danger');
                    }
                });
            });
        });
    </script>
@endsection

@extends('backend.layout.main')
@section('main')
    <div class="page-content">
        <div class="container-fluid">
            <div class="row px-0 mx-0 row-cols-1">
                <div class="table-responsive">
                    <table class="table table-bordered table-hover table-striped align-middle">
                        <thead>
                            <tr>
                                <th>Name</th>
                                <th>Status</th>
                                <th>Created At</th>
                                <th>Last Modified</th>
                            </tr>
                        </thead>
                        <tbody id="tbody">
                            <tr>
                                <td colspan="4" class="text-center">No Records Found!</td>
                            </tr>
                        </tbody>
                    </table>
                </div>
                <div class="col" id="page-row">

                </div>
            </div>
        </div>
    </div>
    {{-- modals --}}
    @include('backend.Category.componenet.modal')
    <script>
        $(document).ready(function() {
            function msg(text, type) {
                $("#alert-box").prepend(`
                    <div class="alert alert-${type} alert-dismissible" role="alert">
                        ${text}
                        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                    </div>
                `);
            };

            function formatTime(time) {
                if (time > 59) {
                    return time / 60 + " min"
                }
                return time + " Secs";
            }

            function formatCounter(number) {
                if (number >= 1000000000) {
                    return Math.floor(number / 1000000000) + 'B' + (number % 1000000000 > 0 ? '+' : '');
                } else if (number >= 1000000) {
                    return Math.floor(number / 1000000) + 'M' + (number % 1000000 > 0 ? '+' : '');
                } else if (number >= 1000) {
                    return Math.floor(number / 1000) + 'k' + (number % 1000 > 0 ? '+' : '');
                } else {
                    return number;
                }
            }

            function formateDate(date) {
                if (date == null) {
                    return null;
                }

                const now = moment();
                const parsedDate = moment(date);

                if (parsedDate.format('DD') === now.format('DD')) {
                    return parsedDate.format('h:mm A');
                } else if (parsedDate.format('YYYY') === now.format('YYYY')) {
                    return parsedDate.format('MMMM, DD h:mm A');
                }

                return parsedDate.format('MMMM, DD YYYY h:mm A');
            }

            function updateRecords(res) {
                if (res.data.data.length > 0) {
                    let tbody = $("#tbody").html('');
                    let _html = '';
                    for (const data of res.data.data) {
                        _html += `@include('backend.Category.componenet.row')`;
                    }
                    tbody.append(_html);
                }
                if (res.data.links.length > 3) {
                    let links = res.data.links;
                    $("#page-row").html('');
                    $("#page-row").append(`
                    <div class="col-12 pt-5 blog-card">
                    <div class="input-group justify-content-center gap-0" id='pagination-row'>
                    </div>
                    <div class="font-size-13 text-center mt-2">
                        Showing
                        ${ res.data.per_page * res.data.current_page + ' out of ' + res.data.total }
                        Records
                    </div>
                        </div>
                    `);
                    for (const index in links) {
                        $("#pagination-row").append(`
                            <a data-role='paginate-link-origin' data-url="${ links[index].url }"
                                class="btn font-size-12 d-flex align-items-center justify-content-center text-truncate ${ links[index].active == 1 ? 'btn-dark' : 'btn-outline-dark ' }${ links[index].url == null ? 'disabled' : '' }">
                                ${ (links[index].label == '&laquo; Previous'? '<i class="fa-regular fa-angles-left"></i> Prev'
                                    : (links[index].label == 'Next &raquo;'
                                        ? 'Next <i class="fa-regular fa-angles-right"></i>'
                                        : links[index].label)) }
                            </a>                    
                        `)
                    }
                }
            };
            $("#page-row").on('click', "[data-role='paginate-link-origin']", function() {
                $('#page-row').css('opacity', '.5');
                let url = $(this).attr('data-url');
                $.ajax({
                    type: 'get',
                    url: url,
                    contentType: false,
                    processData: false,
                    success: function(res) {
                        if (res.status === 200) {
                            updateRecords(res);
                        }
                        $('#page-row').css('opacity', '1');
                    },
                    error: function(err) {
                        msg('Something Went Wrong!', 'danger');
                    },
                });
            })

            function updateRecord(res) {
                if (res.data !== null) {
                    let tr = $("#tbody").find('#tr-' + res.data.id);
                    tr.children('td').eq(0).text(res.data.name);
                    if (res.data.status == '1') {
                        tr.children('td').eq(1).children('span').text('Active');
                        tr.children('td').eq(1).children('span').removeClass('border-danger');
                        tr.children('td').eq(1).children('span').removeClass('text-danger');
                        tr.children('td').eq(1).children('span').addClass('border-success');
                        tr.children('td').eq(1).children('span').addClass('text-success');
                    } else if (res.data.status == '0') {
                        tr.children('td').eq(1).children('span').text('Disabled');
                        tr.children('td').eq(1).children('span').removeClass('border-success');
                        tr.children('td').eq(1).children('span').removeClass('text-success');
                        tr.children('td').eq(1).children('span').addClass('border-danger');
                        tr.children('td').eq(1).children('span').addClass('text-danger');
                    }
                    tr.children('td').eq(2).text(formateDate(res.data.created_at));
                    tr.children('td').eq(3).text(formateDate(res.data.updated_at));
                }
            };

            function fetch_data(url) {
                $.get(
                    url,
                    function(res) {
                        if (res.status != 200) {
                            msg('Something Went Wromg! Try Again Later!', 'danger');
                        } else {
                            updateRecords(res);
                        }
                    },
                );
            }
            fetch_data("{{ route('admin.category.categories') }}");
            $("#tbody").on('click', '[data-role="edit"]', function() {
                let id = $(this).attr('data-id');
                let name = $("#tr-" + id).children('td').eq(0).text();
                let status = $(this).attr('data-status');
                let modal = $("#edit-modal");
                modal.find('#name').val(name);
                modal.find('#id').val(id);
                modal.find('#status-val').val(status);
                modal.modal('show');
            });
            $("#tbody").on('click', '[data-role="delete"]', function() {
                let id = $(this).attr('data-id');
                let modal = $("#delete-modal");
                modal.find('#id').val(id);
                modal.modal('show');
            });
            $("#form-edit").on('submit', function(e) {
                e.preventDefault();
                let formData = new FormData(this);
                let btn = $(this).find('button[type="submit"]');
                let btnHtml = btn.html();
                btn.html(`<span class='spinner-border spinner-border-sm'></span>`);
                btn.attr('disabled', 'disabled');
                $.ajax({
                    url: '{{ route('admin.category.edited') }}',
                    type: 'post',
                    data: formData,
                    contentType: false,
                    processData: false,
                    success: function(res) {
                        btn.html(btnHtml);
                        btn.removeAttr('disabled');
                        if (res.status === 200) {
                            updateRecord(res);
                            msg(res.msg, 'success');
                            $(".form-control").val('');
                            $(".form-select").val('');
                            $("#edit-modal").modal("hide");
                        } else if (res.status === 403) {
                            for (const msgs of res.msg) {
                                msg(msgs, 'danger');
                            }
                        } else if (res.status === 404) {
                            msg(msg, 'danger');
                        } else {
                            msg('Something Went Wromg! Try Again Later!', 'danger');
                        }
                    },
                    error: function(err) {
                        btn.html(btnHtml);
                        btn.removeAttr('disabled');
                        msg('Something Went Wromg! Try Again Later!', 'danger');
                    }
                });
            });
            $("#form-delete").on('submit', function(e) {
                e.preventDefault();
                let formData = new FormData(this);
                let btn = $(this).find('button[type="submit"]');
                let btnHtml = btn.html();
                btn.html(`<span class='spinner-border spinner-border-sm'></span>`);
                btn.attr('disabled', 'disabled');
                $.ajax({
                    url: '{{ route('admin.category.deleted') }}',
                    type: 'post',
                    data: formData,
                    contentType: false,
                    processData: false,
                    success: function(res) {
                        btn.html(btnHtml);
                        btn.removeAttr('disabled');
                        if (res.status === 200) {
                            $("#tr-" + res.data).fadeOut(500);
                            setTimeout(() => {
                                $("#tr-" + res.data).remove();
                            }, 600);
                            msg(res.msg, 'success');
                            $(".form-control").val('');
                            $(".form-select").val('');
                            $("#delete-modal").modal("hide");
                        } else if (res.status === 403) {
                            for (const msgs of res.msg) {
                                msg(msgs, 'danger');
                            }
                        } else if (res.status === 404) {
                            msg(msg, 'danger');
                        } else {
                            msg('Something Went Wromg! Try Again Later!', 'danger');
                        }
                    },
                    error: function(err) {
                        btn.html(btnHtml);
                        btn.removeAttr('disabled');
                        msg('Something Went Wromg! Try Again Later!', 'danger');
                    }
                });
            });
        });
    </script>
@endsection

@extends('backend.layout.main')
@section('main')
    <div class="page-content">
        <div class="container-fluid">
            <form id="form-create"
                class="row row-cols-1 px-0 col-md-6 col-11 justify-content-center shadow mx-auto gy-3 pb-2 border rounded-2 overflow-hidden mb-3">
                <div class="col p-0">
                    <h3 class="h5 text-center bg-dark text-light py-3">Create Plant</h3>
                </div>
                @csrf
                <div class="col">
                    <label for="">Name</label>
                    <input type="text" class="form-control" name="name" placeholder="Enter Name">
                </div>
                <div class="col">
                    <label for="">Feature Image</label>
                    <input type="file" class="form-control" name="feature_image">
                </div>
                <div class="col">
                    <label for="">Image-1</label>
                    <input type="file" class="form-control" name="image[]">
                </div>

                <div class="col">
                    <label for="">Image-2</label>
                    <input type="file" class="form-control" name="image[]">
                </div>

                <div class="col">
                    <label for="">Image-3</label>
                    <input type="file" class="form-control" name="image[]">
                </div>
                <div class="col">
                    <label for="">Category</label>
                    <select name="category" id="category" class="form-select">
                        <option value="">Select Category</option>
                        @foreach ($cats as $cat)
                            <option value="{{ $cat->id }}">{{ $cat->name }}</option>
                        @endforeach
                    </select>
                </div>
                <div class="col">
                    <label for="">Description</label>
                    <textarea name="description" id="description" class="form-control" placeholder="Description"></textarea>
                </div>
                <div class="col">
                    <label for="">Price</label>
                    <input type="number" class="form-control" step="0.001" name="price" placeholder="Enter Price">
                </div>
                <div class="col">
                    <label for="">Discount in Percentage (%)</label>
                    <input type="number" class="form-control" step="0.001" value="0" name="discount"
                        placeholder="Enter Discount">
                </div>
                <div class="col">
                    <label for="">Scientific Name</label>
                    <input type="text" class="form-control" name="scientific_name" placeholder="Enter Scientific Name">
                </div>
                <div class="col">
                    <label for="">Country</label>
                    <select name="country" id="country" class="form-select">
                        <option value="">Select Country</option>
                        @foreach ($countries as $country)
                            <option value="{{ $country }}">{{ $country }}</option>
                        @endforeach
                    </select>
                </div>
                <div class="col">
                    <label for="">Water Cycle</label>
                    <div class="input-group">
                        <input type="number" step="0.001" name="water_cycle" class="form-control"
                            placeholder="Enter Amount">
                        <select name="water_cycle_quantity" id="water_cycle_quantity" class="form-select">
                            <option value="Litre">Litre</option>
                            <option value="ML">ML</option>
                        </select>
                        <select name="water_cycle_time" id="water_cycle_time" class="form-select">
                            <option value="Per Day">Per Day</option>
                            <option value="Per Week">Per Week</option>
                        </select>
                    </div>
                </div>
                <div class="col">
                    <label for="">Light Requirement (optional)</label>
                    <div class="input-group">
                        <input type="number" step="0.001" name="light" class="form-control" placeholder="Enter Amount">
                        <select name="light_quantity" id="light_quantity" class="form-select">
                            <option value="Hour">Hour</option>
                            <option value="Minutes">Minutes</option>
                            <option value="Seconds">Seconds</option>
                        </select>
                        <select name="light_time" id="light_time" class="form-select">
                            <option value="Per Day">Per Day</option>
                            <option value="Per Week">Per Week</option>
                        </select>
                    </div>
                </div>
                <div class="col">
                    <label for="">Quantity</label>
                    <input type="number" class="form-control" step="1" name="quantity"
                        placeholder="Enter Quantity">
                </div>
                <div class="col">
                    <button type="submit" class="btn btn-outline-primary">Create <i
                            class="fa-regular fa-check"></i></button>
                </div>
            </form>
        </div>
    </div>
    <script>
        $(document).ready(function() {
            function msg(text, type) {
                $("#alert-box").prepend(`
                    <div class="alert alert-${type} alert-dismissible" role="alert">
                        ${text}
                        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                    </div>
                `);
            };
            $("#form-create").on('submit', function(e) {
                e.preventDefault();
                let formData = new FormData(this);
                let btn = $(this).find('button[type="submit"]');
                let btnHtml = btn.html();
                btn.html(`<span class='spinner-border spinner-border-sm'></span>`);
                btn.attr('disabled', 'disabled');
                $.ajax({
                    url: '{{ route('admin.plant.created') }}',
                    type: 'post',
                    data: formData,
                    contentType: false,
                    processData: false,
                    success: function(res) {
                        btn.html(btnHtml);
                        btn.removeAttr('disabled');
                        if (res.status === 200) {
                            msg(res.msg, 'success');
                            $(".form-control").val('');
                            $(".form-select").val('');
                        } else if (res.status === 403) {
                            for (const msgs of res.msg) {
                                msg(msgs, 'danger');
                            }
                        } else {
                            msg('Something Went Wromg! Try Again Later!', 'danger');
                        }
                    },
                    error: function(err) {
                        btn.html(btnHtml);
                        btn.removeAttr('disabled');
                        msg('Something Went Wromg! Try Again Later!', 'danger');
                    }
                });
            });
        });
    </script>
@endsection

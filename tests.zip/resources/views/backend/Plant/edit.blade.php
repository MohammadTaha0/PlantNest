@extends('backend.layout.main')
@section('main')
    @php
        $images = explode(',', $plant->images);
    @endphp
    <div class="page-content">
        <div class="container-fluid">
            <form id="form-create"
                class="row row-cols-1 px-0 col-md-6 col-11 justify-content-center shadow mx-auto gy-3 pb-2 border rounded-2 overflow-hidden mb-3">
                <div class="col p-0">
                    <h3 class="h5 text-center bg-dark text-light py-3">Edit Plant</h3>
                </div>
                @csrf
                <div class="col">
                    <label for="">Name</label>
                    <input type="text" class="form-control" name="name" placeholder="Enter Name"
                        value="{{ $plant->name }}">
                </div>
                <input type="hidden" name="id" value="{{ $plant->id }}">
                <div class="col">
                    <label for="">Feature Image</label>
                    <input type="file" class="form-control" name="feature_image">
                    <img src="{{ asset('storage/images/' . $plant->feature) }}" alt="" class="row-img">
                </div>
                <div class="col">
                    <label for="">Image-1</label>
                    <input type="file" class="form-control" name="image_1">
                    <img src="{{ asset('storage/images/' . $images[0]) }}" alt="" class="row-img">
                </div>

                <div class="col">
                    <label for="">Image-2</label>
                    <input type="file" class="form-control" name="image_2">
                    @if (count($images) > 1)
                        <img src="{{ asset('storage/images/' . $images[1]) }}" alt="" class="row-img">
                    @endif
                </div>

                <div class="col">
                    <label for="">Image-3</label>
                    <input type="file" class="form-control" name="image_3">

                    @if (count($images) > 2)
                        <img src="{{ asset('storage/images/' . $images[2]) }}" alt="" class="row-img">
                    @endif
                </div>
                <div class="col">
                    <label for="">Category</label>
                    <select name="category" id="category" class="form-select">
                        <option value="">Select Category</option>
                        @foreach ($cats as $cat)
                            @if ($plant->category == $cat->id)
                                <option value="{{ $cat->id }}" selected>{{ $cat->name }}</option>
                            @else
                                <option value="{{ $cat->id }}">{{ $cat->name }}</option>
                            @endif
                        @endforeach
                    </select>
                </div>
                <div class="col">
                    <label for="">Description</label>
                    <textarea name="description" id="description" class="form-control" placeholder="Description">
                        {{ $plant->description }}
                    </textarea>
                </div>
                <div class="col">
                    <label for="">Price</label>
                    <input type="number" class="form-control" step="0.001" value="{{ $plant->price }}" name="price"
                        placeholder="Enter Price">
                </div>
                <div class="col">
                    <label for="">Discount in Percentage (%)</label>
                    <input type="number" class="form-control" step="0.001" value="{{ $plant->discount }}"
                        name="discount" placeholder="Enter Discount">
                </div>
                <div class="col">
                    <label for="">Scientific Name</label>
                    <input type="text" class="form-control" name="scientific_name" value="{{ $plant->scientific_name }}"
                        placeholder="Enter Scientific Name">
                </div>
                <div class="col">
                    <label for="">Country</label>
                    <select name="country" id="country" class="form-select">
                        <option value="">Select Country</option>
                        @foreach ($countries as $country)
                            @if ($plant->country == $country)
                                <option value="{{ $country }}" selected>{{ $country }}</option>
                            @else
                                <option value="{{ $country }}">{{ $country }}</option>
                            @endif
                        @endforeach
                    </select>
                </div>
                <div class="col">
                    <label for="">Water Cycle</label>
                    <div class="input-group">
                        <input type="number" step="0.001" name="water_cycle" class="form-control"
                            placeholder="Enter Amount" value="{{ $plant->water_cycle }}">
                        <select name="water_cycle_quantity" id="water_cycle_quantity" class="form-select">
                            <option value="Litre" {{ $plant->water_quantity == 'Litre' ? 'selected' : '' }}>Litre
                            </option>
                            <option value="ML" {{ $plant->water_quantity == 'ML' ? 'selected' : '' }}>ML</option>
                        </select>
                        <select name="water_cycle_time" id="water_cycle_time" class="form-select">
                            <option value="Per Day" {{ $plant->water_cycle_time == 'Per Day' ? 'selected' : '' }}>Per Day
                            </option>
                            <option value="Per Week" {{ $plant->water_cycle_time == 'Per Week' ? 'selected' : '' }}>Per
                                Week
                            </option>
                        </select>
                    </div>
                </div>
                <div class="col">
                    <label for="">Light Requirement (optional)</label>
                    <div class="input-group">
                        <input type="number" step="0.001" value="{{ $plant->light }}" name="light"
                            class="form-control" placeholder="Enter Amount">
                        <select name="light_quantity" value='{{ $plant->light_quantity }}' id="light_quantity"
                            class="form-select">
                            <option value="Hour" {{ $plant->light_quantity == 'Hour' ? 'selected' : '' }}>Hour</option>
                            <option value="Minutes" {{ $plant->light_quantity == 'Minutes' ? 'selected' : '' }}>Minutes
                            </option>
                            <option value="Seconds" {{ $plant->light_quantity == 'Seconds' ? 'selected' : '' }}>Seconds
                            </option>
                        </select>
                        <select name="light_time" id="light_time" class="form-select" value='{{ $plant->light_time }}'>
                            <option value="Per Day" {{ $plant->light_time == 'Per Day' ? 'selected' : '' }}>Per Day
                            </option>
                            <option value="Per Week" {{ $plant->light_time == 'Per Week' ? 'selected' : '' }}>Per Week
                            </option>
                        </select>
                    </div>
                </div>
                <div class="col">
                    <label for="">Quantity</label>
                    <input type="number" class="form-control" step="1" value="{{ $plant->quantity }}"
                        name="quantity" placeholder="Enter Quantity">
                </div>
                <div class="col">
                    <button type="submit" class="btn btn-outline-primary">Save <i
                            class="fa-regular fa-check"></i></button>
                </div>
            </form>
        </div>
    </div>
    <script>
        $(document).ready(function() {
            function msg(text, type) {
                $("#alert-box").prepend(`
                    <div class="alert alert-${type} alert-dismissible" role="alert">
                        ${text}
                        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                    </div>
                `);
            };
            $("input[type='file']").change(function(e) {
                let inp = $(this);
                const file = event.target.files[0];
                if (file) {
                    const reader = new FileReader();
                    reader.onload = function() {
                        inp.parent().children('.row-img').remove();
                        inp.parent().append(`<img class='row-img d-block' src='${reader.result}' />`);
                    };
                    reader.readAsDataURL(file);
                } 
            });
            $("#form-create").on('submit', function(e) {
                e.preventDefault();
                let formData = new FormData(this);
                let btn = $(this).find('button[type="submit"]');
                let btnHtml = btn.html();
                btn.html(`<span class='spinner-border spinner-border-sm'></span>`);
                btn.attr('disabled', 'disabled');
                $.ajax({
                    url: '{{ route('admin.plant.edited') }}',
                    type: 'post',
                    data: formData,
                    contentType: false,
                    processData: false,
                    success: function(res) {
                        btn.html(btnHtml);
                        btn.removeAttr('disabled');
                        if (res.status === 200) {
                            msg(res.msg, 'success');
                        } else if (res.status === 403) {
                            for (const msgs of res.msg) {
                                msg(msgs, 'danger');
                            }
                        } else {
                            msg('Something Went Wromg! Try Again Later!', 'danger');
                        }
                    },
                    error: function(err) {
                        btn.html(btnHtml);
                        btn.removeAttr('disabled');
                        msg('Something Went Wromg! Try Again Later!', 'danger');
                    }
                });
            });
        });
    </script>
@endsection

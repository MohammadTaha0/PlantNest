@extends('backend.layout.main')
@section('main')
    <div class="page-content">
        <div class="container-fluid">
            <h5 class="">Coming Soon...</h5>
        </div>
    </div>
@endsection

<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link
    href="https://fonts.googleapis.com/css2?family=Montserrat:ital,wght@0,100;0,200;0,300;0,400;0,500;0,600;0,700;0,800;0,900;1,100;1,200;1,300;1,400;1,500;1,600;1,700;1,800;1,900&family=Poppins:ital,wght@0,100;0,200;0,300;0,400;0,500;0,600;0,700;0,800;0,900;1,100;1,200;1,300;1,400;1,500;1,600;1,700;1,800;1,900&family=Roboto+Slab:wght@100;200;300;400;500;600;700;800;900&family=Space+Grotesk:wght@700&display=swap"
    rel="stylesheet">
<style>
    .ck-editor__editable_inline {
        min-height: 300px;
        border-color: #414242 !important;
    }
/* 
    .ck-reset_all :not(.ck-reset_all-excluded *),
    .ck.ck-reset_all {
        color: #ffffff !important;
        background: #1f262f !important;
        border-color: #414242 !important;
    }

    blockquote {
        border-left: 5px solid white !important;
        padding: 10px 50px;
        font-style: italic !important;
    }

    .list-ol {
        list-style: lower-roman;
    }

    .list-ul {
        list-style: circle;
    }

    .fw-300 {
        font-weight: 300 !important;
    }

    .fw-400 {
        font-weight: 400 !important;
    }

    .fw-500 {
        font-weight: 500 !important;
    }

    .fw-600 {
        font-weight: 600 !important;
    }


    .fw-700 {
        font-weight: 700 !important;
    }


    .fw-800 {
        font-weight: 800 !important;
    }

    .fw-900 {
        font-weight: 900 !important;
    }

    .page-row {
        font-family: 'Poppins', sans-serif !important;
    }

    .img-h-50 {
        width: 100% !important;
        height: 400px !important;
    }

    #preview-row img {
        width: auto !important;
        object-fit: cover !important;
    }

    #preview-row h3,
    #preview-row h4,
    #preview-row h5,
    #preview-row h6,
    #preview-row h2,
    #preview-row h1 {
        margin: 20px 0px;
    }

    blockquote {
        font-style: italic;
        padding: 5px 30px;
        font-weight: 500 !important;
        min-height: 100px !important;
        position: relative;
        display: flex;
        flex-wrap: wrap;
        justify-content: center;
        align-items: center;
        background: linear-gradient(to right, #232F3E, #36495f);
        overflow: hidden;
        text-align: center;
        margin: 40px 0px;
    }

    blockquote::before {
        position: absolute;
        content: '"';
        left: 2%;
        top: 40%;
        width: auto;
        height: 30px;
        padding: 0px;
        color: #ffffff69;
        font-size: 80px;
        transform: rotate(180deg);
        font-family: 'Space Grotesk', sans-serif;
    }

    blockquote>*,
    blockquote a {
        padding: 0px !important;
        margin: 0px !important;
        color: #fff !important;
        text-align: center;
    }

    .image-style-side {
        margin: 0px !important;
        margin-right: 0px !important;
    }

    #preview-row .image-style-side img {
        width: 100% !important;
    }

    .h2-g {
        font-size: 45px !important;
        font-weight: 700 !important;
    } */
</style>

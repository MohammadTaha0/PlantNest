<div class="col-md-4 col-sm-6">
    <div class="product-item">
        <div class="product-img">
            <a href="single-product-variable.html">
                <img class="primary-img" src="{{ asset('storage/images/') }}/${data.feature}" alt="Product Images">
                <img class="secondary-img" src="{{ asset('storage/images/') }}/${data.images.split(',')[0]}"
                    alt="Product Images">
            </a>
            <div class="product-add-action">
                <ul>
                    <li>
                        <a data-role="add-cart" data-id="${data.id}" data-tippy="Add to cart" data-tippy-inertia="true"
                            data-tippy-animation="shift-away" data-tippy-delay="50" data-tippy-arrow="true"
                            data-tippy-theme="sharpborder">
                            ${data.in_cart == '1'?`<i class="pe-7s-cart active-cart"></i>`:`<i class="pe-7s-cart"></i>`}
                        </a>
                    </li>
                </ul>
            </div>
        </div>
        <div class="product-content">
            <a class="product-name" href="single-product-variable.html">${data.name}</a>
            <div class="price-box pb-1">
                <span class="new-price">$${data.price}</span>
            </div>            
        </div>
    </div>
</div>

@extends('frontend.layout.main')
@section('main')
    <!-- Begin Slider Area -->
    <div class="slider-area">

        <!-- Main Slider -->
        <div class="swiper-container main-slider swiper-arrow with-bg_white">
            <div class="swiper-wrapper">
                <div class="swiper-slide animation-style-01">
                    <div class="slide-inner style-1 bg-height"
                        data-bg-image="{{ asset('frontend/assets/images/slider/bg/1-1.jpg') }}">
                        <div class="container">
                            <div class="row">
                                <div class="col-lg-6 order-2 order-lg-1 align-self-center">
                                    <div class="slide-content text-black">
                                        <span class="offer">65% Off</span>
                                        <h2 class="title">New Plant</h2>
                                        <p class="short-desc">Pronia, With 100% Natural, Organic & Plant Shop.</p>
                                        <div class="btn-wrap">
                                            <a class="btn btn-custom-size xl-size btn-pronia-primary"
                                                href="shop.html">Discover Now</a>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-lg-6 col-md-8 offset-md-2 offset-lg-0 order-1 order-lg-2">
                                    <div class="inner-img">
                                        <div class="scene fill">
                                            <div class="expand-width" data-depth="0.2">
                                                <img src="{{ asset('frontend/assets/images/slider/inner-img/1-1-524x617.png') }}"
                                                    alt="Inner Image">
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="swiper-slide animation-style-01">
                    <div class="slide-inner style-1 bg-height"
                        data-bg-image="{{ asset('frontend/assets/images/slider/bg/1-1.jpg') }}">
                        <div class="container">
                            <div class="row">
                                <div class="col-lg-6 order-2 order-lg-1 align-self-center">
                                    <div class="slide-content text-black">
                                        <span class="offer">65% Off</span>
                                        <h2 class="title">New Plant</h2>
                                        <p class="short-desc">Pronia, With 100% Natural, Organic & Plant Shop.</p>
                                        <div class="btn-wrap">
                                            <a class="btn btn-custom-size xl-size btn-pronia-primary"
                                                href="shop.html">Discover Now</a>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-lg-6 col-md-8 offset-md-2 offset-lg-0 order-1 order-lg-2">
                                    <div class="inner-img">
                                        <div class="scene fill">
                                            <div class="expand-width" data-depth="0.2">
                                                <img src="{{ asset('frontend/assets/images/slider/inner-img/1-2-524x617.png') }}"
                                                    alt="Inner Image">
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <!-- Add Pagination -->
            <div class="swiper-pagination d-md-none"></div>

            <!-- Add Arrows -->
            <div class="swiper-button-prev"></div>
            <div class="swiper-button-next"></div>
        </div>

    </div>
    <!-- Slider Area End Here -->

    <!-- Begin Shipping Area -->
    <div class="shipping-area section-space-top-100">
        <div class="container">
            <div class="shipping-bg">
                <div class="row shipping-wrap">
                    <div class="col-lg-4 col-md-6">
                        <div class="shipping-item">
                            <div class="shipping-img">
                                <img src="{{ asset('frontend/assets/images/shipping/icon/car.png') }}" alt="Shipping Icon">
                            </div>
                            <div class="shipping-content">
                                <h2 class="title">Free Shipping</h2>
                                <p class="short-desc mb-0">Capped at $319 per order</p>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-4 col-md-6 mt-4 mt-md-0">
                        <div class="shipping-item">
                            <div class="shipping-img">
                                <img src="{{ asset('frontend/assets/images/shipping/icon/card.png') }}" alt="Shipping Icon">
                            </div>
                            <div class="shipping-content">
                                <h2 class="title">Safe Payment</h2>
                                <p class="short-desc mb-0">With our payment gateway</p>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-4 col-md-6 mt-4 mt-lg-0">
                        <div class="shipping-item">
                            <div class="shipping-img">
                                <img src="{{ asset('frontend/assets/images/shipping/icon/service.png') }}"
                                    alt="Shipping Icon">
                            </div>
                            <div class="shipping-content">
                                <h2 class="title">Best Services</h2>
                                <p class="short-desc mb-0">Friendly & Supper Services</p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- Shipping Area End Here -->

    <!-- Begin Product Area -->
    <div class="product-area section-space-top-100">
        <div class="container">
            <div class="section-title-wrap">
                <h2 class="section-title mb-0">Our Products</h2>
            </div>
            <div class="row">
                <div class="col-xl-3 col-lg-4 order-2 order-lg-1 pt-5 pt-lg-0">
                    <div class="sidebar-area">
                        <div class="widgets-searchbox">
                            <form id="widgets-searchbox">
                                <input class="input-field" type="text" placeholder="Search">
                                <button class="widgets-searchbox-btn" type="submit">
                                    <i class="fa fa-search"></i>
                                </button>
                            </form>
                        </div>
                        <div class="widgets-area">
                            <div class="widgets-item pt-0">
                                <h2 class="widgets-title mb-4">Categories</h2>
                                <ul class="widgets-category" id="categories">

                                </ul>
                            </div>
                            <div class="widgets-item widgets-filter">
                                <h2 class="widgets-title mb-4">Price Filter</h2>
                                <div class="price-filter">
                                    <div class="input-group align-items-center gap-2 justify-content-center">
                                        <input type="number" id="range-from" class="form-control text-center"
                                            step="0.00001">
                                        <label for="" class="p-0 my-0">to</label>
                                        <input type="number" id="range-to" class="form-control text-center"
                                            step="0.00001">
                                    </div>
                                    <button class="btn btn-outline-dark btn-sm w-100 mt-2" id="apply-price">Apply</button>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-lg-9">
                    <div class="product-topbar mt-3">
                        <ul>
                            <li class="page-count">
                                <span id="fetch">12</span> Product Found of <span id="outof">30</span>
                            </li>
                            <li class="short">
                                <select class="nice-select" id="sort">
                                    <option value="l">Sort by Default</option>
                                    <option value="f">Sort by Popularity</option>
                                    {{-- <option value="r">Sort by Rated</option> --}}
                                    <option value="l">Sort by Latest</option>
                                    <option value="hp">Sort by High Price</option>
                                    <option value="lp">Sort by Low Price</option>
                                </select>
                            </li>
                        </ul>
                    </div>
                    <div class="tab-content" id="myTabContent">
                        <div class="tab-pane fade show active" id="latest" role="tabpanel"
                            aria-labelledby="latest-tab">
                            <div class="product-item-wrap row justify-content-center" id="main-row">
                                {{-- @foreach ($famouse as $product)
                                    <div class="col-xl-3 col-md-4 col-sm-6">
                                        <div class="product-item">
                                            <div class="product-img">
                                                <a href="shop.html">
                                                    <img class="primary-img"
                                                        src="{{ asset('storage/images/' . $product->feature) }}"
                                                        alt="Product Images">
                                                    <img class="secondary-img"
                                                        src="{{ asset('storage/images/' . explode(',', $product->images)[0]) }}"
                                                        alt="Product Images">
                                                </a>
                                                <div class="product-add-action">
                                                    <ul>
                                                        <li class="quuickview-btn" data-bs-toggle="modal"
                                                            data-bs-target="#quickModal">
                                                            <a href="#" data-tippy="Quickview"
                                                                data-tippy-inertia="true"
                                                                data-tippy-animation="shift-away" data-tippy-delay="50"
                                                                data-tippy-arrow="true" data-tippy-theme="sharpborder">
                                                                <i class="pe-7s-look"></i>
                                                            </a>
                                                        </li>
                                                        <li>
                                                            <a href="cart.html" data-tippy="Add to cart"
                                                                data-tippy-inertia="true"
                                                                data-tippy-animation="shift-away" data-tippy-delay="50"
                                                                data-tippy-arrow="true" data-tippy-theme="sharpborder">
                                                                <i class="pe-7s-cart"></i>
                                                            </a>
                                                        </li>
                                                    </ul>
                                                </div>
                                            </div>
                                            <div class="product-content">
                                                <a class="product-name" href="shop.html">{{ $product->name }}</a>
                                                <div class="price-box pb-1">
                                                    <span class="new-price">${{ $product->price }}</span>
                                                </div>
                                                <div class="rating-box">
                                                    <ul>
                                                        <li><i class="fa fa-star"></i></li>
                                                        <li><i class="fa fa-star"></i></li>
                                                        <li><i class="fa fa-star"></i></li>
                                                        <li><i class="fa fa-star"></i></li>
                                                        <li><i class="fa fa-star"></i></li>
                                                    </ul>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                @endforeach --}}

                            </div>
                        </div>
                    </div>
                    <div class="pagination-area">
                        <nav aria-label="Page navigation example">
                            <ul class="pagination justify-content-center" id="pagination-area">

                            </ul>
                        </nav>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <script>
        $(document).ready(function() {
            function msg(text, type) {
                Swal.fire({
                    position: 'top-end',
                    icon: type,
                    text: text,
                    showConfirmButton: false,
                    timer: 1000,
                    customClass: {
                        popup: 'small-toast',
                    }
                })
            }

            function formatTime(time) {
                if (time > 59) {
                    return time / 60 + " min"
                }
                return time + " Secs";
            }

            function formatCounter(number) {
                if (number >= 1000000000) {
                    return Math.floor(number / 1000000000) + 'B' + (number % 1000000000 > 0 ? '+' : '');
                } else if (number >= 1000000) {
                    return Math.floor(number / 1000000) + 'M' + (number % 1000000 > 0 ? '+' : '');
                } else if (number >= 1000) {
                    return Math.floor(number / 1000) + 'k' + (number % 1000 > 0 ? '+' : '');
                } else {
                    return number;
                }
            }

            function formateDate(date) {
                if (date == null) {
                    return null;
                }

                const now = moment();
                const parsedDate = moment(date);

                if (parsedDate.format('DD') === now.format('DD')) {
                    return parsedDate.format('h:mm A');
                } else if (parsedDate.format('YYYY') === now.format('YYYY')) {
                    return parsedDate.format('MMMM, DD h:mm A');
                }

                return parsedDate.format('MMMM, DD YYYY h:mm A');
            }

            function updateRecords(res, type) {
                $("#main-row").css("opacity", .2);
                if (res.data.data.length > 0) {
                    let tbody = $("#main-row").html('');
                    let _html = '';
                    for (const data of res.data.data) {
                        _html += `@include('frontend.component.shop')`;
                    }
                    tbody.append(_html);
                } else {
                    $("#main-row").html('<span>No Records Found</span>');

                }
                if (type !== 'price' && type !== 'both') {
                    $("#range-from").attr('min', res.min);
                    $("#range-from").attr('max', res.max);
                    $("#range-from").val(res.min);

                    $("#range-to").attr('min', res.min);
                    $("#range-to").attr('max', res.max);
                    $("#range-to").val(res.max);
                }
                if (type !== 'cat' && type !== 'both') {
                    $("#categories").html('');
                    if (res.categories.length > 0) {
                        for (const cat of res.categories) {
                            $("#categories").append(`<li>
                                                <a class='btn btn-outline-success border-0 text-start' data-role="category" data-id='${cat.id}'>
                                                    <i class="fa fa-chevron-right"></i>
                                                    ${cat.name} <span>(${cat.totals})</span>
                                                </a>
                                            </li>`);
                        }
                    }
                }
                $("#pagination-area").html('');
                $(".blog-card").remove();
                if (res.data.links.length > 3) {
                    let links = res.data.links;
                    $("#pagination-area").parent().append(`
                    <div class="col-12 pt-2 blog-card">
                    <div class="input-group justify-content-center gap-0" id='pagination-row'>
                    </div>
                    <div class="font-size-13 text-center mt-2">
                        Showing
                        ${ res.data.per_page * res.data.current_page + ' out of ' + res.data.total }
                        Records
                    </div>
                        </div>
                    `);
                    $("#fetch").text(res.data.per_page * res.data.current_page);
                    $("#outof").text(res.data.total);
                    for (const index in links) {
                        $("#pagination-area").append(`<li class='page-item ${ links[index].active == 1 ? 'active' : '' }'>
                            <a data-role='paginate-link-origin' style='cursor:pointer;' data-url="${ links[index].url }"
                                class="btn d-flex align-items-center justify-content-center text-truncate page-lik ${ links[index].active == 1 ? 'btn-dark' : 'btn-outline-dark' } ${ links[index].url == null ? 'disabled' : '' }">
                                ${ (links[index].label == '&laquo; Previous'? '<i class="fa-regular fa-angles-left"></i> Prev'
                                    : (links[index].label == 'Next &raquo;'
                                        ? 'Next <i class="fa-regular fa-angles-right"></i>'
                                        : links[index].label)) }
                            </a> 
                            </li>                   
                        `)
                    }
                } else {
                    $("#fetch").text(res.data.total);
                    $("#outof").text(res.data.total);
                }
                $("#main-row").css("opacity", 1);
            };
            $("#widgets-searchbox").find('input').keyup(function() {
                $("#widgets-searchbox").submit();
                if ($(this).val().length === 0) {
                }
            });
            $("#widgets-searchbox").on('submit', function(e) {
                e.preventDefault();
                let val = $(this).find('input');
                let from = $("#range-from").val();
                let to = $("#range-to").val();
                let url = $("[data-role='paginate-link-origin'] .btn-dark");
                if (url.length > 0) {
                    url = url.attr('data-url') + "&"
                } else {
                    url = "{{ route('shop.index.get') }}?";
                }
                if (val.val().length > 0) {
                    fetch_data(url + "key=" + val.val() + "&sort=" + $("#sort").val() + ((from.length > 0 &&
                            to.length > 0) ?
                        "&price_from=" + from + "&price_to=" + to : '') + ($(
                        "#categories").find(".btn-success").length > 0 ? "&category=" + $(
                        "#categories").find(".btn-success").attr('data-id') : ''), ($(
                        "#categories").find(".btn-success").length > 0 ? 'both' : 'cat'));
                } else {
                    fetch_data(url + "sort=" + $("#sort").val() + ((from.length > 0 &&
                            to.length > 0) ?
                        "&price_from=" + from + "&price_to=" + to : '') + ($(
                        "#categories").find(".btn-success").length > 0 ? "&category=" + $(
                        "#categories").find(".btn-success").attr('data-id') : ''), ($(
                        "#categories").find(".btn-success").length > 0 ? 'both' : 'cat'));
                }
            });
            $("#sort").change(function() {
                let val = $(this);
                if (val.val().length > 0) {
                    let from = $("#range-from").val();
                    let to = $("#range-to").val();
                    let url = $("[data-role='paginate-link-origin'] .btn-dark");
                    if (url.length > 0) {
                        url = url.attr('data-url') + "&"
                    } else {
                        url = "{{ route('shop.index.get') }}?";
                    }
                    fetch_data(url + "&sort=" + val.val() + ((from.length > 0 &&
                            to.length > 0) ?
                        "&price_from=" + from + "&price_to=" + to : '') + ($(
                        "#categories").find(".btn-success").length > 0 ? "&category=" + $(
                        "#categories").find(".btn-success").attr('data-id') : '') + ($(
                        "#widgets-searchbox").find('input').length > 0 ? "&key=" + $(
                        "#widgets-searchbox").find('input').val() : ''), ($(
                        "#categories").find(".btn-success").length > 0 ? 'both' : 'cat'));
                }
            });
            $("#apply-price").click(function() {
                let from = $("#range-from").val();
                let to = $("#range-to").val();
                let btn = $(this);
                let btnHtml = btn.html();
                btn.html(`<span class="spinner-border spinner-border-sm"></span>`);
                btn.attr('disabled', 'disabled');
                if (from.length > 0 && to.length > 0) {
                    let url = $("[data-role='paginate-link-origin'] .btn-dark");
                    if (url.length > 0) {
                        url = url.attr('data-url') + "&"
                    } else {
                        url = "{{ route('shop.index.get') }}?";
                    }
                    fetch_data(url + "sort=" + $("#sort").val() + "&price_from=" + from + "&price_to=" +
                        to + ($("#widgets-searchbox").find('input').length > 0 ? "&key=" + $(
                            "#widgets-searchbox").find('input').val() : '') + ($(
                            "#categories").find(".btn-success").length > 0 ? "&category=" + $(
                            "#categories").find(".btn-success").attr('data-id') : ''),
                        ($(
                            "#categories").find(".btn-success").length > 0 ? "both" : 'price'));
                    btn.removeAttr('disabled');
                    btn.html(btnHtml);
                }
            });
            $("#categories").on('click', "[data-role='category']", function() {
                let btn = $(this);
                btn.removeClass('btn-outline-success');
                $(".btn-success").removeClass('btn-success text-light');
                btn.addClass('btn-success text-light');
                let id = btn.attr('data-id');
                let btnHtml = btn.html();
                let from = $("#range-from").val();
                let to = $("#range-to").val();
                btn.html(`<span class="spinner-border spinner-border-sm"></span>`);
                btn.attr('disabled', 'disabled');
                if (id != null) {
                    let url = $("[data-role='paginate-link-origin'] .btn-dark");
                    if (url.length > 0) {
                        url = url.attr('data-url') + "&"
                    } else {
                        url = "{{ route('shop.index.get') }}?";
                    }
                    fetch_data(url + "sort=" + $("#sort").val() + ($("#widgets-searchbox").find('input')
                            .length > 0 ? "&key=" + $("#widgets-searchbox").find('input').val() : '') +
                        ((from.length > 0 && to.length > 0) ?
                            "&price_from=" + from + "&price_to=" + to : '') + "&category=" + id, ((from
                            .length > 0 && to.length > 0) ? 'both' : 'cat'));
                    btn.removeAttr('disabled');
                    btn.html(btnHtml);
                }
            });
            $("#pagination-area").on('click', "[data-role='paginate-link-origin']", function() {
                $('#main-row').css('opacity', '.5');
                let url = $(this).attr('data-url');
                let from = $("#range-from").val();
                let to = $("#range-to").val();
                console.log($("#categories").find(".btn-success").length)
                $.ajax({
                    type: 'get',
                    url: url + "&sort=" + $("#sort").val() + ($("#widgets-searchbox").find('input')
                        .length > 0 ? "&key=" + $("#widgets-searchbox").find('input').val() : ''
                    ) + ((from.length > 0 && to.length > 0) ?
                        "&price_from=" + from + "&price_to=" + to : '') + ($(
                        "#categories").find(".btn-success").length > 0 ? "&category=" + $(
                        "#categories").find(".btn-success").attr('data-id') : ''),
                    contentType: false,
                    processData: false,
                    success: function(res) {
                        if (res.status === 200) {
                            updateRecords(res, ($("#categories").find(".btn-success").length >
                                0 ?
                                'cat' : ''));
                        }
                        $('#main-row').css('opacity', '1');
                    },
                    error: function(err) {
                        msg('Something Went Wrong!', 'error');
                    },
                });
            })
            $("#main-row").on('click', '[data-role="add-cart"]', function() {
                let id = $(this).attr('data-id');
                $(this).find('i').toggleClass('active-cart');
                $.get(
                    "{{ route('shop.index.cart.add') }}?id=" + id,
                    function(res) {
                        msg(res.msg, '');
                        carts("?short=1");
                    }
                );
            });

            function fetch_data(url, type) {
                $.get(
                    url,
                    function(res) {
                        if (res.status != 200) {
                            msg('Something Went Wromg! Try Again Later!', 'error');
                        } else {
                            updateRecords(res, type);
                        }
                    },
                );
            }
            fetch_data("{{ route('shop.index.get') }}?sort=" + $("#sort").val(), '');
        });
    </script>
    <!-- Product Area End Here -->
@endsection

@extends('frontend.layout.main')
@section('main')
    <!-- Begin Main Content Area -->
    <main class="main-content">
        <div class="breadcrumb-area breadcrumb-height" data-bg-image="assets/images/breadcrumb/bg/1-1-1919x388.jpg">
            <div class="container h-100">
                <div class="row h-100">
                    <div class="col-lg-12">
                        <div class="breadcrumb-item">
                            <h2 class="breadcrumb-heading">Shop</h2>
                            <ul>
                                <li>
                                    <a href="index.html">Home</a>
                                </li>
                                <li>Shop Default</li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="shop-area section-space-y-axis-100">
            <div class="container">
                <div class="row">
                    <div class="col-xl-3 col-lg-4 order-2 order-lg-1 pt-5 pt-lg-0">
                        <div class="sidebar-area">
                            <div class="widgets-searchbox">
                                <form id="widgets-searchbox">
                                    <input class="input-field" type="text" placeholder="Search">
                                    <button class="widgets-searchbox-btn" type="submit">
                                        <i class="fa fa-search"></i>
                                    </button>
                                </form>
                            </div>
                            <div class="widgets-area">
                                <div class="widgets-item pt-0">
                                    <h2 class="widgets-title mb-4">Categories</h2>
                                    <ul class="widgets-category" id="categories">

                                    </ul>
                                </div>
                                <div class="widgets-item widgets-filter">
                                    <h2 class="widgets-title mb-4">Price Filter</h2>
                                    <div class="price-filter">
                                        <div class="input-group align-items-center gap-2 justify-content-center">
                                            <input type="number" id="range-from" class="form-control text-center"
                                                step="0.00001">
                                            <label for="" class="p-0 my-0">to</label>
                                            <input type="number" id="range-to" class="form-control text-center"
                                                step="0.00001">
                                        </div>
                                        <button class="btn btn-outline-dark btn-sm w-100 mt-2"
                                            id="apply-price">Apply</button>
                                    </div>
                                </div>
                                {{-- <div class="widgets-item">
                                    <h2 class="widgets-title mb-4">Populer Tags</h2>
                                    <ul class="widgets-tag">
                                        <li>
                                            <a href="#">Fashion</a>
                                        </li>
                                        <li>
                                            <a href="#">Organic</a>
                                        </li>
                                        <li>
                                            <a href="#">Old Fashion</a>
                                        </li>
                                        <li>
                                            <a href="#">Men</a>
                                        </li>
                                        <li>
                                            <a href="#">Fashion</a>
                                        </li>
                                        <li>
                                            <a href="#">Dress</a>
                                        </li>
                                    </ul>
                                </div> --}}
                            </div>
                            {{-- <div class="banner-item widgets-banner img-hover-effect">
                                <div class="banner-img">
                                    <img src="assets/images/sidebar/banner/1-270x300.jpg" alt="Banner Image">
                                </div>
                                <div class="banner-content text-position-center">
                                    <span class="collection">New Collection</span>
                                    <h3 class="title">Plant Port</h3>
                                    <div class="button-wrap">
                                        <a class="btn btn-custom-size sm-size btn-pronia-primary" href="#">Shop
                                            Now</a>
                                    </div>
                                </div>
                            </div> --}}
                        </div>
                    </div>
                    <div class="col-xl-9 col-lg-8 order-1 order-lg-2">
                        <div class="product-topbar">
                            <ul>
                                <li class="page-count">
                                    <span id="fetch">12</span> Product Found of <span id="outof">30</span>
                                </li>
                                <li class="short">
                                    <select class="nice-select" id="sort">
                                        <option value="l">Sort by Default</option>
                                        <option value="f">Sort by Popularity</option>
                                        {{-- <option value="r">Sort by Rated</option> --}}
                                        <option value="l">Sort by Latest</option>
                                        <option value="hp">Sort by High Price</option>
                                        <option value="lp">Sort by Low Price</option>
                                    </select>
                                </li>
                            </ul>
                        </div>
                        <div class="tab-content">
                            <div class="tab-pane fade show active" id="grid-view" role="tabpanel"
                                aria-labelledby="grid-view-tab">
                                <div class="product-grid-view row g-y-20" id="main-row">

                                </div>
                            </div>                           
                        </div>
                        <div class="pagination-area">
                            <nav aria-label="Page navigation example">
                                <ul class="pagination justify-content-center" id="pagination-area">

                                </ul>
                            </nav>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </main>
    <!-- Main Content Area End Here -->
    <script>
        $(document).ready(function() {
            function msg(text, type) {
                Swal.fire({
                    position: 'top-end',
                    icon: type,
                    text: text,
                    showConfirmButton: false,
                    timer: 1000,
                    customClass: {
                        popup: 'small-toast',
                    }
                })
            }

            function formatTime(time) {
                if (time > 59) {
                    return time / 60 + " min"
                }
                return time + " Secs";
            }

            function formatCounter(number) {
                if (number >= 1000000000) {
                    return Math.floor(number / 1000000000) + 'B' + (number % 1000000000 > 0 ? '+' : '');
                } else if (number >= 1000000) {
                    return Math.floor(number / 1000000) + 'M' + (number % 1000000 > 0 ? '+' : '');
                } else if (number >= 1000) {
                    return Math.floor(number / 1000) + 'k' + (number % 1000 > 0 ? '+' : '');
                } else {
                    return number;
                }
            }

            function formateDate(date) {
                if (date == null) {
                    return null;
                }

                const now = moment();
                const parsedDate = moment(date);

                if (parsedDate.format('DD') === now.format('DD')) {
                    return parsedDate.format('h:mm A');
                } else if (parsedDate.format('YYYY') === now.format('YYYY')) {
                    return parsedDate.format('MMMM, DD h:mm A');
                }

                return parsedDate.format('MMMM, DD YYYY h:mm A');
            }

            function updateRecords(res, type) {
                $("#main-row").css("opacity", .2);
                if (res.data.data.length > 0) {
                    let tbody = $("#main-row").html('');
                    let _html = '';
                    for (const data of res.data.data) {
                        _html += `@include('frontend.component.shop')`;
                    }
                    tbody.append(_html);
                } else {
                    $("#main-row").html('<span>No Records Found</span>');

                }
                if (type !== 'price' && type !== 'both') {
                    $("#range-from").attr('min', res.min);
                    $("#range-from").attr('max', res.max);
                    $("#range-from").val(res.min);

                    $("#range-to").attr('min', res.min);
                    $("#range-to").attr('max', res.max);
                    $("#range-to").val(res.max);
                }
                if (type !== 'cat' && type !== 'both') {
                    $("#categories").html('');
                    if (res.categories.length > 0) {
                        for (const cat of res.categories) {
                            $("#categories").append(`<li>
                                                <a class='btn btn-outline-success border-0 text-start' data-role="category" data-id='${cat.id}'>
                                                    <i class="fa fa-chevron-right"></i>
                                                    ${cat.name} <span>(${cat.totals})</span>
                                                </a>
                                            </li>`);
                        }
                    }
                }
                $("#pagination-area").html('');
                $(".blog-card").remove();
                if (res.data.links.length > 3) {
                    let links = res.data.links;
                    $("#pagination-area").parent().append(`
                    <div class="col-12 pt-2 blog-card">
                    <div class="input-group justify-content-center gap-0" id='pagination-row'>
                    </div>
                    <div class="font-size-13 text-center mt-2">
                        Showing
                        ${ res.data.per_page * res.data.current_page + ' out of ' + res.data.total }
                        Records
                    </div>
                        </div>
                    `);
                    $("#fetch").text(res.data.per_page * res.data.current_page);
                    $("#outof").text(res.data.total);
                    for (const index in links) {
                        $("#pagination-area").append(`<li class='page-item ${ links[index].active == 1 ? 'active' : '' }'>
                            <a data-role='paginate-link-origin' style='cursor:pointer;' data-url="${ links[index].url }"
                                class="btn d-flex align-items-center justify-content-center text-truncate page-lik ${ links[index].active == 1 ? 'btn-dark' : 'btn-outline-dark' } ${ links[index].url == null ? 'disabled' : '' }">
                                ${ (links[index].label == '&laquo; Previous'? '<i class="fa-regular fa-angles-left"></i> Prev'
                                    : (links[index].label == 'Next &raquo;'
                                        ? 'Next <i class="fa-regular fa-angles-right"></i>'
                                        : links[index].label)) }
                            </a> 
                            </li>                   
                        `)
                    }
                } else {
                    $("#fetch").text(res.data.total);
                    $("#outof").text(res.data.total);
                }
                $("#main-row").css("opacity", 1);
            };
            $("#widgets-searchbox").find('input').keyup(function() {
                $("#widgets-searchbox").submit();
                if ($(this).val().length === 0) {
                }
            });
            $("#widgets-searchbox").on('submit', function(e) {
                e.preventDefault();
                let val = $(this).find('input');
                let from = $("#range-from").val();
                let to = $("#range-to").val();
                let url = $("[data-role='paginate-link-origin'] .btn-dark");
                if (url.length > 0) {
                    url = url.attr('data-url') + "&"
                } else {
                    url = "{{ route('shop.index.get') }}?";
                }
                if (val.val().length > 0) {
                    fetch_data(url + "key=" + val.val() + "&sort=" + $("#sort").val() + ((from.length > 0 &&
                            to.length > 0) ?
                        "&price_from=" + from + "&price_to=" + to : '') + ($(
                        "#categories").find(".btn-success").length > 0 ? "&category=" + $(
                        "#categories").find(".btn-success").attr('data-id') : ''), ($(
                        "#categories").find(".btn-success").length > 0 ? 'both' : 'cat'));
                } else {
                    fetch_data(url + "sort=" + $("#sort").val() + ((from.length > 0 &&
                            to.length > 0) ?
                        "&price_from=" + from + "&price_to=" + to : '') + ($(
                        "#categories").find(".btn-success").length > 0 ? "&category=" + $(
                        "#categories").find(".btn-success").attr('data-id') : ''), ($(
                        "#categories").find(".btn-success").length > 0 ? 'both' : 'cat'));
                }
            });
            $("#sort").change(function() {
                let val = $(this);
                if (val.val().length > 0) {
                    let from = $("#range-from").val();
                    let to = $("#range-to").val();
                    let url = $("[data-role='paginate-link-origin'] .btn-dark");
                    if (url.length > 0) {
                        url = url.attr('data-url') + "&"
                    } else {
                        url = "{{ route('shop.index.get') }}?";
                    }
                    fetch_data(url + "&sort=" + val.val() + ((from.length > 0 &&
                            to.length > 0) ?
                        "&price_from=" + from + "&price_to=" + to : '') + ($(
                        "#categories").find(".btn-success").length > 0 ? "&category=" + $(
                        "#categories").find(".btn-success").attr('data-id') : '') + ($(
                        "#widgets-searchbox").find('input').length > 0 ? "&key=" + $(
                        "#widgets-searchbox").find('input').val() : ''), ($(
                        "#categories").find(".btn-success").length > 0 ? 'both' : 'cat'));
                }
            });
            $("#apply-price").click(function() {
                let from = $("#range-from").val();
                let to = $("#range-to").val();
                let btn = $(this);
                let btnHtml = btn.html();
                btn.html(`<span class="spinner-border spinner-border-sm"></span>`);
                btn.attr('disabled', 'disabled');
                if (from.length > 0 && to.length > 0) {
                    let url = $("[data-role='paginate-link-origin'] .btn-dark");
                    if (url.length > 0) {
                        url = url.attr('data-url') + "&"
                    } else {
                        url = "{{ route('shop.index.get') }}?";
                    }
                    fetch_data(url + "sort=" + $("#sort").val() + "&price_from=" + from + "&price_to=" +
                        to + ($("#widgets-searchbox").find('input').length > 0 ? "&key=" + $(
                            "#widgets-searchbox").find('input').val() : '') + ($(
                            "#categories").find(".btn-success").length > 0 ? "&category=" + $(
                            "#categories").find(".btn-success").attr('data-id') : ''),
                        ($(
                            "#categories").find(".btn-success").length > 0 ? "both" : 'price'));
                    btn.removeAttr('disabled');
                    btn.html(btnHtml);
                }
            });
            $("#categories").on('click', "[data-role='category']", function() {
                let btn = $(this);
                btn.removeClass('btn-outline-success');
                $(".btn-success").removeClass('btn-success text-light');
                btn.addClass('btn-success text-light');
                let id = btn.attr('data-id');
                let btnHtml = btn.html();
                let from = $("#range-from").val();
                let to = $("#range-to").val();
                btn.html(`<span class="spinner-border spinner-border-sm"></span>`);
                btn.attr('disabled', 'disabled');
                if (id != null) {
                    let url = $("[data-role='paginate-link-origin'] .btn-dark");
                    if (url.length > 0) {
                        url = url.attr('data-url') + "&"
                    } else {
                        url = "{{ route('shop.index.get') }}?";
                    }
                    fetch_data(url + "sort=" + $("#sort").val() + ($("#widgets-searchbox").find('input')
                            .length > 0 ? "&key=" + $("#widgets-searchbox").find('input').val() : '') +
                        ((from.length > 0 && to.length > 0) ?
                            "&price_from=" + from + "&price_to=" + to : '') + "&category=" + id, ((from
                            .length > 0 && to.length > 0) ? 'both' : 'cat'));
                    btn.removeAttr('disabled');
                    btn.html(btnHtml);
                }
            });
            $("#pagination-area").on('click', "[data-role='paginate-link-origin']", function() {
                $('#main-row').css('opacity', '.5');
                let url = $(this).attr('data-url');
                let from = $("#range-from").val();
                let to = $("#range-to").val();
                console.log($("#categories").find(".btn-success").length)
                $.ajax({
                    type: 'get',
                    url: url + "&sort=" + $("#sort").val() + ($("#widgets-searchbox").find('input')
                        .length > 0 ? "&key=" + $("#widgets-searchbox").find('input').val() : ''
                    ) + ((from.length > 0 && to.length > 0) ?
                        "&price_from=" + from + "&price_to=" + to : '') + ($(
                        "#categories").find(".btn-success").length > 0 ? "&category=" + $(
                        "#categories").find(".btn-success").attr('data-id') : ''),
                    contentType: false,
                    processData: false,
                    success: function(res) {
                        if (res.status === 200) {
                            updateRecords(res, ($("#categories").find(".btn-success").length >
                                0 ?
                                'cat' : ''));
                        }
                        $('#main-row').css('opacity', '1');
                    },
                    error: function(err) {
                        msg('Something Went Wrong!', 'error');
                    },
                });
            })
            $("#main-row").on('click', '[data-role="add-cart"]', function() {
                let id = $(this).attr('data-id');
                $(this).find('i').toggleClass('active-cart');
                $.get(
                    "{{ route('shop.index.cart.add') }}?id=" + id,
                    function(res) {
                        msg(res.msg, '');
                        carts("?short=1");
                    }
                );
            });

            function fetch_data(url, type) {
                $.get(
                    url,
                    function(res) {
                        if (res.status != 200) {
                            msg('Something Went Wromg! Try Again Later!', 'error');
                        } else {
                            updateRecords(res, type);
                        }
                    },
                );
            }
            fetch_data("{{ route('shop.index.get') }}?sort=" + $("#sort").val(), '');
        });
    </script>
@endsection

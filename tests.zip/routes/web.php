<?php

use App\Http\Controllers\CategoryController;
use App\Http\Controllers\CheckoutController;
use App\Http\Controllers\DashboardController;
use App\Http\Controllers\HomeController;
use App\Http\Controllers\PlantController;
use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider and all of them will
| be assigned to the "web" middleware group. Make something great!
|
*/

// Route::get('/', function () {
//     return view('welcome');
// });
Route::get('/', [HomeController::class, 'index'])->name('home');
Route::prefix('cart')->group(function () {
    Route::get('/', [PlantController::class, 'cart'])->name('cart.index');
});
Route::prefix('checkout')->group(function () {
    Route::get('/', [CheckoutController::class, 'index'])->name('checkout.index');
});
Route::prefix('shop')->group(function () {
    Route::get('/', [PlantController::class, 'shop'])->name('shop.index');
    Route::get('/get', [PlantController::class, 'shop_get'])->name('shop.index.get');
    Route::get('/get-cart', [PlantController::class, 'get_cart'])->name('shop.index.get-cart');
    Route::get('/add-cart', [PlantController::class, 'add_cart'])->name('shop.index.cart.add');
    Route::get('/update-cart', [PlantController::class, 'update_qty'])->name('shop.index.cart.update');
});
Route::prefix('admin')->group(function () {
    Route::get('/', [DashboardController::class, 'index'])->name('admin.dashboard');
    Route::prefix('category')->group(function () {
        Route::get('/create', [CategoryController::class, 'create'])->name('admin.category.create');
        Route::post('/created', [CategoryController::class, 'created'])->name('admin.category.created');
        Route::get('/index', [CategoryController::class, 'admin_index'])->name('admin.category.index');
        Route::post('/edited', [CategoryController::class, 'edited'])->name('admin.category.edited');
        Route::post('/deleted', [CategoryController::class, 'deleted'])->name('admin.category.deleted');
        Route::get('/categories', [CategoryController::class, 'categories'])->name('admin.category.categories');
    });
    Route::prefix('plant')->group(function () {
        Route::get('/create', [PlantController::class, 'create'])->name('admin.plant.create');
        Route::post('/created', [PlantController::class, 'created'])->name('admin.plant.created');
        Route::get('/index', [PlantController::class, 'admin_index'])->name('admin.plant.index');
        Route::get('/edit/{id?}', [PlantController::class, 'edit'])->name('admin.plant.edit');
        Route::post('/edited', [PlantController::class, 'edited'])->name('admin.plant.edited');
        Route::post('/deleted', [PlantController::class, 'deleted'])->name('admin.plant.deleted');
        Route::get('/plants', [PlantController::class, 'plants'])->name('admin.plant.plants');
    });
});

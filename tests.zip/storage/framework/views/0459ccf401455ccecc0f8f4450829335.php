<li class="minicart-product" id="cart-${data.id}">
    <a class="product-item_remove" data-role="remove-cart" data-id="${data.id}"><i class="pe-7s-close" data-tippy="Remove"
            data-tippy-inertia="true" data-tippy-animation="shift-away" data-tippy-delay="50" data-tippy-arrow="true"
            data-tippy-theme="sharpborder"></i></a>
    <a href="single-product-variable.html" class="product-item_img">
        <img class="img-full" src="<?php echo e(asset('storage/images/')); ?>/${data.feature}" alt="Product Image">
    </a>
    <div class="product-item_content">
        <a class="product-item_title" href="single-product-variable.html">${data.name}</a>
        <span class="product-item_quantity">${data.qty} x $${data.price}</span>
        ${(data.stock=='0' || data.quantity <= 0)?`<span class="badge bg-danger fw-normal">Out Of Stock</span>`:''}
            <input type="hidden" name="price-cart" value="${data.price}">
    </div>
</li>
<?php /**PATH E:\plantplace\plantplace\resources\views/frontend/component/cart-list.blade.php ENDPATH**/ ?>
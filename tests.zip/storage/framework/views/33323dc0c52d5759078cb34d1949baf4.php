<tr>
    <td class="product_remove">
        <a data-role="remove-cart" data-id="${data.id}">
            <i class="pe-7s-close" data-tippy="Remove" data-tippy-inertia="true" data-tippy-animation="shift-away"
                data-tippy-delay="50" data-tippy-arrow="true" data-tippy-theme="sharpborder"></i>
        </a>
    </td>
    <td class="product-thumbnail">
        <a>
            <img src="<?php echo e(asset('storage/images/')); ?>/${data.feature}" alt="Cart Thumbnail">
        </a>
    </td>
    <td class="product-name"><a>${data.name}</a></td>
    <td class="product-price">$<span class="amount">${data.price}</span></td>
    <td width="4%">
        <input type="number" class="form-control form-control-sm text-center" min="1" max="${data.quantity}" name="quantity-cart-row" value="${data.qty}"
            data-id="${data.id}">
        ${(data.stock=='0' || data.quantity <= 0)?`<span class="badge bg-danger fw-normal mt-2">Out Of Stock</span>`:''}
            <input type="hidden" name="price-cart" value="${data.price}">
    </td>
    <td class="product-subtotal">$<span class="amount">${(parseFloat(data.price) * parseInt(data.qty)).toFixed(2)}</span></td>
</tr>
<?php /**PATH E:\plantplace\plantplace\resources\views/frontend/component/cart-row.blade.php ENDPATH**/ ?>
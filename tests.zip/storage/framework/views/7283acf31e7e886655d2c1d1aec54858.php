<!DOCTYPE html>
<html lang="zxx">


<!-- Mirrored from htmldemo.net/pronia/pronia/<?php echo e(route('home')); ?> by HTTrack Website Copier/3.x [XR&CO'2010], Wed, 09 Aug 2023 20:02:47 GMT -->

<head>

    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title>Pronia - Plant Store Bootstrap 5 Template</title>
    <meta name="robots" content="index, follow" />
    <meta name="description"
        content="Pronia plant store bootstrap 5 template is an awesome website template for any home plant shop.">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <!-- Favicon -->
    <link rel="shortcut icon" type="image/x-icon" href="<?php echo e(asset('frontend/assets/images/favicon.ico')); ?>" />
    <script src="<?php echo e(asset('backend/libs/jquery/jquery.min.js')); ?>"></script>

    <!-- CSS
    ============================================ -->
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>

    <link rel="stylesheet" href="<?php echo e(asset('frontend/assets/css/bootstrap.min.css')); ?>" />
    <link rel="stylesheet" href="<?php echo e(asset('frontend/assets/css/font-awesome.min.css')); ?>" />
    <link rel="stylesheet" href="<?php echo e(asset('frontend/assets/css/Pe-icon-7-stroke.css')); ?>" />
    <link rel="stylesheet" href="<?php echo e(asset('frontend/assets/css/animate.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('frontend/assets/css/swiper-bundle.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('frontend/assets/css/nice-select.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('frontend/assets/css/magnific-popup.min.css')); ?>" />
    <link rel="stylesheet" href="<?php echo e(asset('frontend/assets/css/ion.rangeSlider.min.css')); ?>" />

    <!-- Style CSS -->
    <link rel="stylesheet" href="<?php echo e(asset('frontend/assets/css/style.css')); ?>">
    <style>
        .active-cart {
            background: #abd373 !important;
            color: #fff;
        }

        .small-toast {
            width: 200px;
            /* Adjust the width as needed */
            font-size: 12px;
            /* Adjust the font size as needed */
        }
    </style>

</head>

<body>
    <div class="preloader-activate preloader-active open_tm_preloader">
        <div class="preloader-area-wrap">
            <div class="spinner d-flex justify-content-center align-items-center h-100">
                <div class="bounce1"></div>
                <div class="bounce2"></div>
                <div class="bounce3"></div>
            </div>
        </div>
    </div>
    <div class="main-wrapper">

        <!-- Begin Main Header Area -->
        <header class="main-header-area">
            <div class="header-middle py-30">
                <div class="container">
                    <div class="row align-items-center">
                        <div class="col-lg-12">
                            <div class="header-middle-wrap position-relative">

                                <a href="<?php echo e(route('home')); ?>" class="h3 fw-normal">
                                    <span class="text-bg-success p-2 rounded-start-pill">Plant</span><span
                                        class="border border-success border-3 p-1 px-2 rounded-start-pill">Nest</span>
                                </a>

                                <div class="header-right">
                                    <ul>
                                        <li class="minicart-wrap me-3 me-lg-0">
                                            <a href="#miniCart" class="minicart-btn toolbar-btn">
                                                <i class="pe-7s-shopbag"></i>
                                                <span class="quantity">
                                                    <?php if(session('cart')): ?>
                                                        <?php echo e(count(session('cart'))); ?>

                                                    <?php else: ?>
                                                        0
                                                    <?php endif; ?>
                                                </span>
                                            </a>
                                        </li>
                                        <li class="mobile-menu_wrap d-block d-lg-none">
                                            <a href="#mobileMenu" class="mobile-menu_btn toolbar-btn pl-0">
                                                <i class="pe-7s-menu"></i>
                                            </a>
                                        </li>
                                    </ul>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="header-bottom d-none d-lg-block">
                <div class="container">
                    <div class="row">
                        <div class="col-lg-12">
                            <div class="main-menu position-relative">
                                <nav class="main-nav">
                                    <ul>
                                        <li>
                                            <a href="<?php echo e(route('home')); ?>">Home</a>

                                        </li>
                                        <li>
                                            <a href="<?php echo e(route('shop.index')); ?>">Shop</a>

                                        </li>
                                        <li>
                                            <a href="<?php echo e(route('home')); ?>">About Us</a>
                                        </li>
                                        <li>
                                            <a href="<?php echo e(route('home')); ?>">Contact Us</a>
                                        </li>
                                    </ul>
                                </nav>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="header-sticky py-4 py-lg-0">
                <div class="container">
                    <div class="header-nav position-relative">
                        <div class="row align-items-center">
                            <div class="col-lg-3 col-6">

                                <a href="<?php echo e(route('home')); ?>" class="h3 fw-normal">
                                    <span class="text-bg-success p-2 rounded-start-pill">Plant</span><span
                                        class="border border-success border-3 p-1 px-2 rounded-start-pill">Nest</span>
                                </a>

                            </div>
                            <div class="col-lg-6 d-none d-lg-block">
                                <div class="main-menu">
                                    <nav class="main-nav">
                                        <ul>
                                            <li>
                                                <a href="<?php echo e(route('home')); ?>">Home</a>

                                            </li>
                                            <li>
                                                <a href="<?php echo e(route('shop.index')); ?>">Shop</a>

                                            </li>
                                            <li>
                                                <a href="<?php echo e(route('home')); ?>">About Us</a>
                                            </li>
                                            <li>
                                                <a href="<?php echo e(route('home')); ?>">Contact Us</a>
                                            </li>
                                        </ul>
                                    </nav>
                                </div>
                            </div>
                            <div class="col-lg-3 col-6">
                                <div class="header-right">
                                    <ul>
                                        <li class="minicart-wrap me-3 me-lg-0">
                                            <a href="#miniCart" class="minicart-btn toolbar-btn">
                                                <i class="pe-7s-shopbag"></i>
                                                <span class="quantity">
                                                    <?php if(session('cart')): ?>
                                                        <?php echo e(count(session('cart'))); ?>

                                                    <?php else: ?>
                                                        0
                                                    <?php endif; ?>
                                                </span>
                                            </a>
                                        </li>
                                        <li class="mobile-menu_wrap d-block d-lg-none">
                                            <a href="#mobileMenu" class="mobile-menu_btn toolbar-btn pl-0">
                                                <i class="pe-7s-menu"></i>
                                            </a>
                                        </li>
                                    </ul>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="mobile-menu_wrapper" id="mobileMenu">
                <div class="offcanvas-body">
                    <div class="inner-body">
                        <div class="offcanvas-top">
                            <a href="<?php echo e(route('home')); ?>" class="button-close"><i class="pe-7s-close"></i></a>
                        </div>
                        <div class="offcanvas-menu_area">
                            <nav class="offcanvas-navigation">
                                <ul class="mobile-menu">
                                    <li class="menu-item-has-children">
                                        <a href="<?php echo e(route('home')); ?>">
                                            <span class="mm-text">Home
                                            </span>
                                        </a>
                                    </li>
                                    <li>
                                        <a href="<?php echo e(route('home')); ?>">
                                            <span class="mm-text">Shop
                                                <i class="pe-7s-angle-down"></i>
                                            </span>
                                        </a>
                                    </li>
                                </ul>
                            </nav>
                        </div>
                    </div>
                </div>
            </div>
            <div class="modal fade" id="exampleModal" tabindex="-1" aria-labelledby="exampleModal"
                aria-hidden="true">
                <div class="modal-dialog modal-fullscreen">
                    <div class="modal-content modal-bg-dark">
                        <div class="modal-header">
                            <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"
                                data-tippy="Close" data-tippy-inertia="true" data-tippy-animation="shift-away"
                                data-tippy-delay="50" data-tippy-arrow="true" data-tippy-theme="sharpborder">
                            </button>
                        </div>
                        <div class="modal-body">
                            <div class="modal-search">
                                <span class="searchbox-info">Start typing and press Enter to search or ESC to
                                    close</span>
                                <form action="#" class="hm-searchbox">
                                    <input type="text" name="Search..." value="Search..."
                                        onblur="if(this.value==''){this.value='Search...'}"
                                        onfocus="if(this.value=='Search...'){this.value=''}" autocomplete="off">
                                    <button class="search-btn" type="submit" aria-label="searchbtn">
                                        <i class="pe-7s-search"></i>
                                    </button>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="offcanvas-minicart_wrapper" id="miniCart">
                <div class="offcanvas-body">
                    <div class="minicart-content">
                        <div class="minicart-heading">
                            <h4 class="mb-0">Shopping Cart</h4>
                            <a href="<?php echo e(route('home')); ?>" class="button-close"><i class="pe-7s-close"
                                    data-tippy="Close" data-tippy-inertia="true" data-tippy-animation="shift-away"
                                    data-tippy-delay="50" data-tippy-arrow="true"
                                    data-tippy-theme="sharpborder"></i></a>
                        </div>
                        <ul class="minicart-list">

                        </ul>
                    </div>
                    <div class="minicart-item_total">
                        <span>Subtotal</span>
                        <span class="ammount">$<span>0</span></span>
                    </div>
                    <div class="group-btn_wrap d-grid gap-2">
                        <a href="<?php echo e(route('cart.index')); ?>" class="btn btn-dark">View Cart</a>
                        <a href="checkout.html" class="btn btn-dark">Checkout</a>
                    </div>
                </div>
            </div>
            <div class="global-overlay"></div>
        </header>
        <script>
            function msg(text, type) {
                Swal.fire({
                    position: 'top-end',
                    icon: type,
                    text: text,
                    showConfirmButton: false,
                    timer: 1000,
                    customClass: {
                        popup: 'small-toast', // This is a class you need to define in your CSS
                    }
                })
            }

            function carts(type, page = null, cartHtml = null) {
                $.get(
                    "<?php echo e(route('shop.index.get-cart')); ?>" + type,
                    function(res) {
                        if (res.status === 200) {
                            if (page !== null) {
                                if (page == 'carts') {
                                    $("#carts-tbody").html('');
                                }
                            }
                            let html = '';
                            for (const data of res.data) {
                                html += `<?php echo $__env->make('frontend.component.cart-list', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>`;
                                if (page !== null) {
                                    if (page == 'carts') {
                                        if(cartHtml ==null){
                                            $("#carts-tbody").append(`<?php echo $__env->make('frontend.component.cart-row', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>`);
                                        }else{
                                            $("#carts-tbody").append(`<?php echo $__env->make('frontend.component.cart-checkout-row', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>`);
                                        }
                                    }
                                }
                            }
                            $(".minicart-list").html(html);
                            $(".quantity").text(res.data.length);
                            $(".ammount").children('span').text(res.data.reduce(function(total, data) {
                                return (parseFloat(total) + (parseFloat(data.price) * parseInt(data.qty)))
                                    .toFixed(2);
                            }, 0));
                        } else if (res.status === 404) {
                            if (page !== null) {
                                if (page == 'carts') {
                                    $("#carts-tbody").html(`<tr><td colspan='6' class='text-center'>Empty Card!</td></tr>`);
                                }
                            }
                            $(".ammount").children('span').text(0);
                            $(".quantity").text(0);
                            $(".minicart-list").html(`<span>${res.msg}</span>`);
                        }
                    }

                );
            }
        </script>
        <?php echo $__env->yieldContent('main'); ?>

        <!-- Begin Scroll To Top -->
        <a class="scroll-to-top" href="<?php echo e(route('home')); ?>">
            <i class="fa fa-angle-double-up"></i>
        </a>
        <!-- Scroll To Top End Here -->

    </div>

    <!-- Global Vendor, plugins JS -->

    <!-- JS Files
        ============================================ -->

    <script src="<?php echo e(asset('frontend/assets/js/vendor/bootstrap.bundle.min.js')); ?>"></script>
    <script src="<?php echo e(asset('frontend/assets/js/vendor/jquery-3.6.0.min.js')); ?>"></script>
    <script src="<?php echo e(asset('frontend/assets/js/vendor/jquery-migrate-3.3.2.min.js')); ?>"></script>
    <script src="<?php echo e(asset('frontend/assets/js/vendor/jquery.waypoints.js')); ?>"></script>
    <script src="<?php echo e(asset('frontend/assets/js/vendor/modernizr-3.11.2.min.js')); ?>"></script>
    <script src="<?php echo e(asset('frontend/assets/js/plugins/wow.min.js')); ?>"></script>
    <script src="<?php echo e(asset('frontend/assets/js/plugins/swiper-bundle.min.js')); ?>"></script>
    <script src="<?php echo e(asset('frontend/assets/js/plugins/jquery.nice-select.js')); ?>"></script>
    <script src="<?php echo e(asset('frontend/assets/js/plugins/parallax.min.js')); ?>"></script>
    <script src="<?php echo e(asset('frontend/assets/js/plugins/jquery.magnific-popup.min.js')); ?>"></script>
    <script src="<?php echo e(asset('frontend/assets/js/plugins/tippy.min.js')); ?>"></script>
    <script src="<?php echo e(asset('frontend/assets/js/plugins/ion.rangeSlider.min.js')); ?>"></script>
    <script src="<?php echo e(asset('frontend/assets/js/plugins/mailchimp-ajax.js')); ?>"></script>
    <script src="<?php echo e(asset('frontend/assets/js/plugins/jquery.counterup.js')); ?>"></script>

    <!--Main JS (Common Activation Codes)-->
    <script src="<?php echo e(asset('frontend/assets/js/main.js')); ?>"></script>

</body>

<script>
    $(document).ready(function() {

        carts("?short=1");
        $(".minicart-list").on('click', '[data-role="remove-cart"]', function() {
            let id = $(this).attr('data-id');
            $(this).find('i').toggleClass('active-cart');
            $.get(
                "<?php echo e(route('shop.index.cart.add')); ?>?id=" + id,
                function(res) {
                    carts("?short=1", 'carts');
                }
            );
        });
    })
</script>
<!-- Mirrored from htmldemo.net/pronia/pronia/<?php echo e(route('home')); ?> by HTTrack Website Copier/3.x [XR&CO'2010], Wed, 09 Aug 2023 20:03:50 GMT -->

</html>
<?php /**PATH E:\plantplace\plantplace\resources\views/frontend/layout/main.blade.php ENDPATH**/ ?>
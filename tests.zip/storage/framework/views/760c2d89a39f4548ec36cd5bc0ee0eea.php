
<?php $__env->startSection('main'); ?>
    <style>
        tr td img {
            width: 100px !important;
        }
    </style>
    <!-- Begin Main Content Area -->
    <main class="main-content">
        <div class="breadcrumb-area breadcrumb-height" data-bg-image="assets/images/breadcrumb/bg/1-1-1919x388.jpg">
            <div class="container h-100">
                <div class="row h-100">
                    <div class="col-lg-12">
                        <div class="breadcrumb-item">
                            <h2 class="breadcrumb-heading">Cart Page</h2>
                            <ul>
                                <li>
                                    <a href="index.html">Home</a>
                                </li>
                                <li>Cart Page</li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="cart-area section-space-y-axis-100">
            <div class="container">
                <div class="row">
                    <div class="col-12">
                        <div class="table-content table-responsive">
                            <table class="table">
                                <thead>
                                    <tr>
                                        <th class="product_remove">remove</th>
                                        <th class="product-thumbnail">images</th>
                                        <th class="cart-product-name">Product</th>
                                        <th class="product-price">Unit Price</th>
                                        <th class="product-quantity">Quantity</th>
                                        <th class="product-subtotal">Total</th>
                                    </tr>
                                </thead>
                                <tbody id="carts-tbody">

                                </tbody>
                            </table>
                        </div>
                        <div class="row">
                            <div class="col-md-5 ml-auto">
                                <div class="cart-page-total">
                                    <h2>Cart totals</h2>
                                    <ul>
                                        <li class="ammount">Subtotal ($)<span>0</span></li>
                                        <li class="ammount">Total ($)<span>0</span></li>
                                    </ul>
                                    <a href="<?php echo e(route('checkout.index')); ?>">Proceed to checkout</a>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </main>
    <!-- Main Content Area End Here -->
    <script>
        $(document).ready(function() {
            carts("?short=1", 'carts');
            $('#carts-tbody').on('blur', '[name="quantity-cart-row"]', function() {
                $("#carts-tbody").css('opacity', .3);
                let id = $(this).attr('data-id');
                let qty = $(this).val();
                if (qty <= 0) {
                    msg('Quantity Must be Greater Than 0', 'error');
                    return false;
                }
                return new Promise(function(resolve, reject) {
                    $.get("<?php echo e(route('shop.index.cart.update')); ?>?id=" + id + "&qty=" + qty,
                        function(res) {
                            if (res.status === 200) {
                                resolve();
                            } else if (res.status == 203) {
                                msg(res.msg, 'error');
                            } else {
                                msg('Something Went Wrong', 'error');
                                reject();
                            }
                            carts("?short=1", 'carts');
                            $("#carts-tbody").css('opacity', 1);
                        });
                })
            })
            $("#carts-tbody").on('click', '[data-role="remove-cart"]', function() {
                let id = $(this).attr('data-id');
                $(this).find('i').toggleClass('active-cart');
                $.get(
                    "<?php echo e(route('shop.index.cart.add')); ?>?id=" + id,
                    function(res) {
                        carts("?short=1", 'carts');
                    }
                );
            });
        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('frontend.layout.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\plantplace\plantplace\resources\views/frontend/cart.blade.php ENDPATH**/ ?>
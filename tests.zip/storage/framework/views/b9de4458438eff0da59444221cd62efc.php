${data.stock == '1'?`<tr class="cart_item">
    <td class="cart-product-name"> ${data.name}<strong
    class="product-quantity">
    × ${data.qty}</strong></td>
    <td class="cart-product-total"><span class="amount">$${data.price}</span></td>
</tr>
`:''}
<?php /**PATH E:\plantplace\plantplace\resources\views/frontend/component/cart-checkout-row.blade.php ENDPATH**/ ?>
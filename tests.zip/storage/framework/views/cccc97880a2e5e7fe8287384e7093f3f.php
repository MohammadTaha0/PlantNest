
<?php $__env->startSection('main'); ?>
    <div class="page-content">
        <div class="container-fluid">
            <h5 class="">Coming Soon...</h5>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('backend.layout.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\plantplace\plantplace\resources\views/backend/index.blade.php ENDPATH**/ ?>
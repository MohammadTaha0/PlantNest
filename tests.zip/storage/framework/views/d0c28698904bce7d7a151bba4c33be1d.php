<tr id='tr-${data.id}'>
    <td>${data.name}</td>
    <td>${data.status=='1'?`<span
            class="badge border border-success text-success fw-normal text-capitalize">Active</span>`:`<span
            class="badge border border-danger text-danger fw-normal text-capitalize">Disabled</span>`}</td>
    <td>${formateDate(data.created_at)}</td>
    <td>${formateDate(data.updated_at)}</td>\
    <td>
        <div class="input-group">
            <button data-status="${data.status}" data-id="${data.id}" data-role="edit"
                class="btn btn-sm btn-outline-success"><i class="fa-regular fa-edit"></i></button>
            <button data-id="${data.id}" data-role="delete" class="btn btn-sm btn-outline-danger"><i
                    class="fa-regular fa-trash"></i></button>
        </div>
    </td>
</tr>
<?php /**PATH E:\plantplace\plantplace\resources\views/backend/Category/componenet/row.blade.php ENDPATH**/ ?>
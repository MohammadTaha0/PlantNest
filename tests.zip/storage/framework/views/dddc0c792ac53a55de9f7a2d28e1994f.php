<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8" />
    <title>PlantNest</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="Made By DigiTech Pakistan" />
    <meta name="keywords"
        content="document manager, file manager, taha, mohammad taha, digitechpakistan, digi texh pakistan, hans masroor" />
    <meta content="Mohammad Taha" name="author" />
    <script src="<?php echo e(asset('backend/libs/jquery/jquery.min.js')); ?>"></script>
    <!-- favicon -->
    <link rel="shortcut icon" href="<?php echo e(asset('backend/images/favicon.ico')); ?>" />

    <!-- plugin css -->
    <link href="<?php echo e(asset('backend/libs/jsvectormap/css/jsvectormap.min.css')); ?>" rel="stylesheet" type="text/css" />

    <!-- Layout Js -->
    <script src="<?php echo e(asset('backend/js/layout.js')); ?>"></script>
    <!-- Bootstrap Css -->
    <link href="<?php echo e(url('/backend/css/bootstrap.min.css')); ?>" rel="stylesheet" type="text/css" />
    <!-- Icons Css -->
    <link href="<?php echo e(asset('/backend/css/icons.min.css')); ?>" rel="stylesheet" type="text/css" />
    <!-- App Css-->
    <link href="<?php echo e(asset('/backend/css/app.min.css')); ?>" rel="stylesheet" type="text/css" />
    <link rel="stylesheet" href="https://site-assets.fontawesome.com/releases/v6.4.0/css/all.css">
    <link rel="stylesheet" href="https://unicons.iconscout.com/release/v4.0.8/css/line.css">
    <style>
        .row-img{
            width: 100px !important;
        }
        .text-center {
            text-align: center !important;
        }

        .alert {
            z-index: 99999999 !important;
            animation: alert-popup .5s;
        }

        @keyframes alert-popup {
            0% {
                transform: scale(40%, 40%);
            }

            50% {
                transform: scale(110%, 100%);
            }

            100% {
                transform: scale(100%, 100%);
            }

        }

        .table-img {
            width: 150px !important;
            object-fit: cover !important;
        }

        .modal {
            animation: .5s zoom-in;
            transform: scale(100%, 100%);
        }

        @keyframes zoom-in {
            0% {
                transform: scale(0%, 0%);
            }

            50% {
                transform: scale(110%, 110%);
            }

            100% {
                transform: scale(100%, 100%);
            }
        }

        .zoom-out {
            transition: .5s;
            transform: scale(0%, 0%);
        }
    </style>
</head>


<body data-bs-theme="light" data-sidebar="colored">
    <div class="bg-light position-fixed w-100 h-00 row justify-content-center align-items-center top-0 start-0"
        style="height: 100vh !important; z-index: 9999999999999999999 !important;" id="main-loader">
        <div class="text-center d-flex align-items-center justify-content-center">
            <span class="spinner-border spinner-border-lg"></span><span class="ms-2" id="loading-text">Loading. Please
                Wait....</span>
        </div>
    </div>
    <!-- <body data-layout="horizontal" data-topbar="dark"> -->

    <!-- Begin page -->
    <div id="layout-wrapper">
        <header id="page-topbar">
            <div class="navbar-header">
                <div class="d-flex align-items-center w-100">
                    <!-- LOGO -->
                    <div class="navbar-brand-box">
                        <a href="" class="logo logo-dark">

                        </a>

                        <a href="" class="logo logo-light">

                            PlantNest
                        </a>
                    </div>
                    <button type="button"
                        class=" ms-auto btn btn-sm px-3 font-size-24 header-item waves-effect d-lg-none"
                        data-bs-toggle="collapse" data-bs-target="#vertical-menu-content">
                        <i class="ri-menu-2-line align-middle"></i>
                    </button>
                </div>

                <div class="d-flex">
                    <div class="dropdown d-none d-lg-inline-block ms-1">
                        <button type="button" class="btn header-item noti-icon waves-effect" data-toggle="fullscreen">
                            <i class="ri-fullscreen-line"></i>
                        </button>
                    </div>
                    </button>
                </div>
            </div>
        </header>
        <!-- ========== Left Sidebar Start ========== -->
        <div class="vertical-menu" id="vertical-menu-content">

            <!-- LOGO -->
            <div class="navbar-brand-box text-center">
                <a href="index.html" class="logo text-light text-center h6">
                    PlantNest
                </a>

            </div>

            

            <div data-simplebar class="vertical-scroll">

                <!--- Sidemenu -->
                <div id="sidebar-menu">


                    <!-- Left Menu Start -->
                    <ul class="metismenu list-unstyled" id="side-menu">

                        <li class="menu-title">Menu</li>

                        <li>
                            <a href="" class="waves-effect" href="<?php echo e(route('admin.dashboard')); ?>">
                                <i class="fa-regular fa-airplay"></i> Dashboard
                            </a>
                        </li>
                        <li>
                            <a class="has-arrow waves-effect">
                                <i class="fa-regular fa-list"></i> Category
                            </a>
                            <ul class="sub-menu" aria-expanded="true">
                                <li><a class="dropdown-item" href="<?php echo e(route('admin.category.create')); ?>"> <i class="fa-regular fa-plus"></i>
                                        Create</a></li>
                                <li><a class="dropdown-item" href="<?php echo e(route('admin.category.index')); ?>"> <i class="fa-regular fa-gear"></i>
                                        Manage</a></li>
                            </ul>
                        </li>
                        <li>
                            <a class="has-arrow waves-effect">
                                <i class="fa-regular fa-list"></i> Plant
                            </a>
                            <ul class="sub-menu" aria-expanded="true">
                                <li><a class="dropdown-item" href="<?php echo e(route('admin.plant.create')); ?>"> <i class="fa-regular fa-plus"></i>
                                        Create</a></li>
                                <li><a class="dropdown-item" href="<?php echo e(route('admin.plant.index')); ?>"> <i class="fa-regular fa-gear"></i>
                                        Manage</a></li>
                            </ul>
                        </li>
                    </ul>

                </div>
                <!-- Sidebar -->
            </div>
        </div>

        <!-- ============================================================== -->
        <!-- Start right Content here -->
        <!-- ============================================================== -->
        <div class="main-content">
            <div class="position-fixed col-6 top-0" id="alert-box"
                style="left: 25%;z-index: 99999999999999999999999999 !important;">

            </div>
            <?php echo $__env->yieldContent('main'); ?>

            <footer class="footer">
                <div class="container-fluid">
                    <div class="row">
                        <div class="col-sm-6">
                            2023 - 2025 © PlantNest.
                        </div>
                        <div class="col-sm-6">
                            <div class="text-sm-end d-none d-sm-block">
                                Crafted with <i class="mdi mdi-heart text-danger"></i> by Mohammad Taha
                            </div>
                        </div>
                    </div>
                </div>
            </footer>

        </div>
        <!-- end main content-->

    </div>
    <!-- END layout-wrapper -->

    <!-- JAVASCRIPT -->
    <script src="<?php echo e(asset('backend/libs/bootstrap/js/bootstrap.bundle.min.js')); ?>"></script>
    <script src="<?php echo e(asset('backend/libs/metismenu/metisMenu.min.js')); ?>"></script>
    <script src="<?php echo e(asset('backend/libs/simplebar/simplebar.min.js')); ?>"></script>
    <script src="<?php echo e(asset('backend/libs/node-waves/waves.min.js')); ?>"></script>
    <!-- App js -->
    <script src="<?php echo e(asset('backend/js/app.js')); ?>"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/moment.js/2.29.1/moment.min.js"></script>
    
    <script>
        $(document).ready(function() {
            setTimeout(() => {
                $("#main-loader").fadeOut();
            }, 1000);
            $(".modal-close").click(function() {
                $(this).closest('.modal').addClass('zoom-out');
                setTimeout(() => {
                    $(this).closest('.modal').removeClass('d-block');
                    $(this).closest('.modal').removeClass('zoom-out');
                }, 600);
            });
        })
    </script>
</body>
</html>
<?php /**PATH E:\plantplace\plantplace\resources\views/backend/layout/main.blade.php ENDPATH**/ ?>
 <!-- Add New Section MODAL -->
 <div class="modal fade" id="edit-modal" data-bs-backdrop="static" data-bs-keyboard="false" tabindex="-1" aria-hidden="true">
     <div class="modal-dialog modal-dialog-centered">
         <div class="modal-content">
             <div class="modal-header py-3 px-4">
                 <h5 class="modal-title" id="modal-title">Edit</h5>
                 <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
             </div>

             <div class="modal-body p-4">
                 <form class="needs-validation" name="section-form" id="form-edit" novalidate>
                     <div class="row">
                         <div class="col-12">
                             <div class="mb-3">
                                 <label class="form-label">Name</label>
                                 <input type="hidden" name="id" id="id">
                                 <input class="form-control" placeholder="Enter Name" type="text" name="name"
                                     id="name" required value="">
                             </div>
                             <?php echo csrf_field(); ?>
                         </div> <!-- end col-->

                         <div class="col-12">
                             <div class="mb-3">
                                 <select name="status" class="form-select" id="status-val">
                                     <option value="1">Active</option>
                                     <option value="0">Disbaled</option>
                                 </select>
                             </div>
                         </div> <!-- end col-->
                     </div> <!-- end row-->
                     <div class="row mt-2">
                         <div class="col-6 text-start">
                             <button type="button" class="btn btn-light me-1" data-bs-dismiss="modal">Close</button>
                             <button type="submit" class="btn btn-success">Save</button>
                         </div> <!-- end col-->
                     </div> <!-- end row-->
                 </form>
             </div>
         </div>
         <!-- end modal-content-->
     </div>
     <!-- end modal dialog-->
 </div>
 
 <div class="modal fade" id="delete-modal" data-bs-backdrop="static" data-bs-keyboard="false" tabindex="-1"
     aria-hidden="true">
     <div class="modal-dialog modal-dialog-centered">
         <div class="modal-content">
             <div class="modal-header py-3 px-4">
                 <h5 class="modal-title" id="modal-title">Delete</h5>
                 <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
             </div>

             <div class="modal-body p-4">
                 <form class="needs-validation" id="form-delete" novalidate>
                     <div class="row">
                         <div class="col-12">
                             <div class="mb-3">
                                 <input type="hidden" name="id" id="id">
                             </div>
                             <?php echo csrf_field(); ?>
                         </div> <!-- end col-->
                     </div> <!-- end row-->
                     <div class="row mt-2">
                         <div class="col-6 text-start">
                             <button type="button" class="btn btn-light me-1" data-bs-dismiss="modal">Close</button>
                             <button type="submit" class="btn btn-danger">Confirm</button>
                         </div> <!-- end col-->
                     </div> <!-- end row-->
                 </form>
             </div>
         </div>
         <!-- end modal-content-->
     </div>
     <!-- end modal dialog-->
 </div>
<?php /**PATH E:\plantplace\plantplace\resources\views/backend/Category/componenet/modal.blade.php ENDPATH**/ ?>